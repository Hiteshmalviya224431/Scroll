package app.scroll.tracker.presentation.goals

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.overlay.MindfulBreakScreenContent
import app.scroll.tracker.presentation.components.GlassCard
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollAmber
import app.scroll.tracker.ui.theme.ScrollGreen
import app.scroll.tracker.ui.theme.ScrollRed
import app.scroll.tracker.ui.theme.ScrollTheme
import kotlin.math.roundToInt

@Composable
fun GoalsScreen(
    settings: ScrollSettings,
    onUpdateDailyGoal: (Int) -> Unit,
    onUpdateThresholds: (Int, Int) -> Unit,
    onUpdateNudges: (Boolean, Boolean) -> Unit,
    onUpdateMindfulBreak: (Boolean, Int, Int) -> Unit,
    onUpdateQuietHours: (Boolean, Int, Int) -> Unit
) {
    var showMindfulPreview by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Daily Reel Limit Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Reel Limit",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${settings.dailyReelGoal} reels / day",
                            style = MaterialTheme.typography.titleLarge,
                            color = ElectricViolet,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Slider(
                        value = settings.dailyReelGoal.toFloat(),
                        onValueChange = { onUpdateDailyGoal((it / 5f).roundToInt() * 5) },
                        valueRange = 20f..350f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricViolet,
                            activeTrackColor = ElectricViolet
                        )
                    )

                    // Notch Color Thresholds
                    Text(
                        text = "Notch Pill Color Shift Thresholds",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Green < ${settings.greenThreshold}", color = ScrollGreen, style = MaterialTheme.typography.bodyMedium)
                        Text("Amber ${settings.greenThreshold}–${settings.amberThreshold}", color = ScrollAmber, style = MaterialTheme.typography.bodyMedium)
                        Text("Red ${settings.amberThreshold}+", color = ScrollRed, style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onUpdateThresholds(50, 150) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Default (50 / 150)", style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = { onUpdateThresholds(30, 90) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Strict (30 / 90)", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }

        // Gentle Nudge Notifications (80% & 100%)
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Gentle Goal Nudges",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Heads-up at 80% (${(settings.dailyReelGoal * 0.8f).toInt()} reels)",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Silent notification before you hit your limit",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.nudgeAt80Percent,
                            onCheckedChange = { onUpdateNudges(it, settings.nudgeAt100Percent) }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Limit reached at 100% (${settings.dailyReelGoal} reels)",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Reminder when you reach your daily goal",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.nudgeAt100Percent,
                            onCheckedChange = { onUpdateNudges(settings.nudgeAt80Percent, it) }
                        )
                    }
                }
            }
        }

        // Mindful Break Breathing Overlay Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mindful Break Breathing Overlay",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Pauses continuous binge sessions with a 4s breathing guide",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.mindfulBreakEnabled,
                            onCheckedChange = {
                                onUpdateMindfulBreak(
                                    it,
                                    settings.mindfulBreakReelsThreshold,
                                    settings.mindfulBreakMinutesThreshold
                                )
                            }
                        )
                    }

                    if (settings.mindfulBreakEnabled) {
                        Text(
                            text = "Trigger after ${settings.mindfulBreakReelsThreshold} consecutive reels in one session",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NeonPink
                        )
                        Slider(
                            value = settings.mindfulBreakReelsThreshold.toFloat(),
                            onValueChange = {
                                onUpdateMindfulBreak(
                                    true,
                                    (it / 5f).roundToInt() * 5,
                                    settings.mindfulBreakMinutesThreshold
                                )
                            },
                            valueRange = 10f..100f,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonPink,
                                activeTrackColor = NeonPink
                            )
                        )

                        Text(
                            text = "Or after ${settings.mindfulBreakMinutesThreshold} minutes of non-stop scrolling",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ElectricViolet
                        )
                        Slider(
                            value = settings.mindfulBreakMinutesThreshold.toFloat(),
                            onValueChange = {
                                onUpdateMindfulBreak(
                                    true,
                                    settings.mindfulBreakReelsThreshold,
                                    it.roundToInt()
                                )
                            },
                            valueRange = 5f..45f
                        )

                        Button(
                            onClick = { showMindfulPreview = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricViolet.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Preview Mindful Breathing Overlay",
                                color = ElectricViolet,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Quiet Hours Card
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Quiet Hours (Pause Tracking & Overlay)",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Active window: ${settings.quietStartHour}:00 to ${settings.quietEndHour}:00",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = settings.quietHoursEnabled,
                            onCheckedChange = {
                                onUpdateQuietHours(it, settings.quietStartHour, settings.quietEndHour)
                            }
                        )
                    }

                    if (settings.quietHoursEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val nextStart = (settings.quietStartHour + 1) % 24
                                    onUpdateQuietHours(true, nextStart, settings.quietEndHour)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Start: ${settings.quietStartHour}:00")
                            }
                            OutlinedButton(
                                onClick = {
                                    val nextEnd = (settings.quietEndHour + 1) % 24
                                    onUpdateQuietHours(true, settings.quietStartHour, nextEnd)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("End: ${settings.quietEndHour}:00")
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(28.dp)) }
    }

    if (showMindfulPreview) {
        Dialog(
            onDismissRequest = { showMindfulPreview = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            MindfulBreakScreenContent(
                sessionReels = settings.mindfulBreakReelsThreshold,
                sessionMinutes = settings.mindfulBreakMinutesThreshold,
                appName = "Instagram Reels",
                onTakeBreak = { showMindfulPreview = false },
                onContinueScrolling = { showMindfulPreview = false }
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun GoalsScreenPreview() {
    ScrollTheme {
        GoalsScreen(
            settings = ScrollSettings(),
            onUpdateDailyGoal = {},
            onUpdateThresholds = { _, _ -> },
            onUpdateNudges = { _, _ -> },
            onUpdateMindfulBreak = { _, _, _ -> },
            onUpdateQuietHours = { _, _, _ -> }
        )
    }
}
