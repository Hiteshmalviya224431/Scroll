package app.scroll.tracker.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.scroll.tracker.data.SampleDataGenerator
import app.scroll.tracker.data.preferences.UserPreferencesRepository
import app.scroll.tracker.data.repository.ScrollRepository
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.domain.model.DayHeatmapPoint
import app.scroll.tracker.domain.model.NotchPosition
import app.scroll.tracker.domain.model.NotchSize
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.domain.model.ThemePreference
import app.scroll.tracker.domain.model.TrackedApp
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val scrollRepository: ScrollRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val settingsState: StateFlow<ScrollSettings> = preferencesRepository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ScrollSettings()
        )

    val dashboardMetrics: StateFlow<DailyDashboardMetrics> = scrollRepository.observeDashboardMetrics()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SampleDataGenerator.previewDashboardMetrics()
        )

    val heatmap30Days: StateFlow<List<DayHeatmapPoint>> = scrollRepository.observe30DayHeatmap()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = SampleDataGenerator.preview30DayHeatmap()
        )

    init {
        viewModelScope.launch {
            scrollRepository.seedDemoDataIfEmpty()
        }
    }

    fun setOnboardingCompleted() {
        viewModelScope.launch { preferencesRepository.setOnboardingCompleted(true) }
    }

    fun setAccessibilityDisclosureAccepted() {
        viewModelScope.launch { preferencesRepository.setAccessibilityDisclosureAccepted(true) }
    }

    fun updateDailyGoal(goal: Int) {
        viewModelScope.launch { preferencesRepository.updateDailyGoal(goal) }
    }

    fun updateThresholds(green: Int, amber: Int) {
        viewModelScope.launch { preferencesRepository.updateThresholds(green, amber) }
    }

    fun updateNudges(nudge80: Boolean, nudge100: Boolean) {
        viewModelScope.launch { preferencesRepository.updateNudgeSettings(nudge80, nudge100) }
    }

    fun updateMindfulBreak(enabled: Boolean, reels: Int, minutes: Int) {
        viewModelScope.launch { preferencesRepository.updateMindfulBreakSettings(enabled, reels, minutes) }
    }

    fun updateQuietHours(enabled: Boolean, startHour: Int, endHour: Int) {
        viewModelScope.launch { preferencesRepository.updateQuietHours(enabled, startHour, endHour) }
    }

    fun updateNotchPosition(position: NotchPosition) {
        viewModelScope.launch { preferencesRepository.updateNotchPosition(position) }
    }

    fun updateNotchSize(size: NotchSize) {
        viewModelScope.launch { preferencesRepository.updateNotchSize(size) }
    }

    fun updateNotchOpacity(opacity: Float) {
        viewModelScope.launch { preferencesRepository.updateNotchOpacity(opacity) }
    }

    fun updateAlwaysShowOverlay(alwaysShow: Boolean) {
        viewModelScope.launch { preferencesRepository.updateAlwaysShowOverlay(alwaysShow) }
    }

    fun updateHideOnLockscreen(hide: Boolean) {
        viewModelScope.launch { preferencesRepository.updateHideOnLockscreen(hide) }
    }

    fun toggleTrackedPackage(pkg: String, enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.toggleTrackedPackage(pkg, enabled) }
    }

    fun updateTheme(themePreference: ThemePreference, dynamicColor: Boolean) {
        viewModelScope.launch { preferencesRepository.updateTheme(themePreference, dynamicColor) }
    }

    fun simulateReelScroll(packageName: String = TrackedApp.INSTAGRAM_REELS.packageName) {
        viewModelScope.launch {
            scrollRepository.recordVerifiedReelScroll(packageName = packageName)
        }
    }

    fun seedDemoData() {
        viewModelScope.launch {
            scrollRepository.resetAllData()
            scrollRepository.seedDemoDataIfEmpty()
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            scrollRepository.resetAllData()
        }
    }

    fun exportCsv(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val csv = scrollRepository.exportCsvContent()
            onReady(csv)
        }
    }
}
