package app.scroll.tracker.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.LinearProgressIndicator
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.room.Room
import app.scroll.tracker.MainActivity
import app.scroll.tracker.data.local.ScrollDatabase
import java.time.LocalDate

class ScrollGlanceWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val db = Room.databaseBuilder(
            context.applicationContext,
            ScrollDatabase::class.java,
            "scroll_tracker.db"
        ).build()

        val todayIso = LocalDate.now().toString()
        val eventsToday = runCatching { db.scrollDao().getEventsForDate(todayIso).size }.getOrDefault(0)
        val summaries = runCatching { db.scrollDao().getAllDailySummaries() }.getOrDefault(emptyList())
        val dailyGoal = summaries.firstOrNull()?.dailyGoal ?: 100
        val progress = (eventsToday.toFloat() / dailyGoal.toFloat()).coerceIn(0f, 1f)

        provideContent {
            GlanceTheme {
                Column(
                    modifier = GlanceModifier
                        .fillMaxSize()
                        .cornerRadius(24.dp)
                        .background(ColorProvider(Color(0xFF0B0B14)))
                        .clickable(actionStartActivity<MainActivity>())
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "SCROLL TODAY",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFC084FC)),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(4.dp))
                    Text(
                        text = "$eventsToday",
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "/ $dailyGoal reels",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFA1A1AA)),
                            fontSize = 11.sp
                        )
                    )
                    Spacer(modifier = GlanceModifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = progress,
                        color = ColorProvider(
                            when {
                                eventsToday < 50 -> Color(0xFF00E676)
                                eventsToday < 150 -> Color(0xFFFFB300)
                                else -> Color(0xFFFF1744)
                            }
                        ),
                        backgroundColor = ColorProvider(Color(0xFF232334)),
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .cornerRadius(4.dp)
                    )
                }
            }
        }
    }

    companion object {
        suspend fun updateAllWidgets(context: Context) {
            runCatching { ScrollGlanceWidget().updateAll(context) }
        }
    }
}

class ScrollGlanceWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ScrollGlanceWidget()
}
