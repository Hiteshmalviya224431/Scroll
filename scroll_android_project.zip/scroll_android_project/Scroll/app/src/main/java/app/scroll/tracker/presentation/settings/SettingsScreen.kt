package app.scroll.tracker.presentation.settings

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Policy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.scroll.tracker.domain.model.NotchPosition
import app.scroll.tracker.domain.model.NotchSize
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.domain.model.ThemePreference
import app.scroll.tracker.domain.model.TrackedApp
import app.scroll.tracker.overlay.NotchPillComposable
import app.scroll.tracker.presentation.components.GlassCard
import app.scroll.tracker.presentation.onboarding.requestIgnoreBatteryOptimization
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollGreen
import app.scroll.tracker.ui.theme.ScrollRed

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: ScrollSettings,
    todayCount: Int,
    onBack: () -> Unit,
    onUpdateNotchPosition: (NotchPosition) -> Unit,
    onUpdateNotchSize: (NotchSize) -> Unit,
    onUpdateNotchOpacity: (Float) -> Unit,
    onUpdateAlwaysShowOverlay: (Boolean) -> Unit,
    onUpdateHideOnLockscreen: (Boolean) -> Unit,
    onToggleTrackedPackage: (String, Boolean) -> Unit,
    onUpdateTheme: (ThemePreference, Boolean) -> Unit,
    onExportCsv: ((String) -> Unit) -> Unit,
    onResetData: () -> Unit,
    onSimulateScrollForPackage: (String) -> Unit,
    onSeedDemoData: () -> Unit
) {
    val context = LocalContext.current
    var previewCount by remember(todayCount) { mutableIntStateOf(todayCount.coerceAtLeast(42)) }
    var previewPulseTs by remember { mutableLongStateOf(0L) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Notch Studio", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Live Interactive Notch Counter Studio & Preview
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Notch Counter Live Preview",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Simulated Top Status Bar with Camera Cutout
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF060609))
                                .border(1.dp, Color(0xFF27273A), RoundedCornerShape(16.dp))
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                if (settings.notchPosition == NotchPosition.LEFT) {
                                    NotchPillComposable(
                                        count = previewCount,
                                        pulseTimestamp = previewPulseTs,
                                        settings = settings
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                // Simulated camera hole-punch cutout
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black)
                                        .border(1.5.dp, Color(0xFF3F3F46), CircleShape)
                                )

                                if (settings.notchPosition == NotchPosition.RIGHT ||
                                    settings.notchPosition == NotchPosition.TOP_CENTER
                                ) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    NotchPillComposable(
                                        count = previewCount,
                                        pulseTimestamp = previewPulseTs,
                                        settings = settings
                                    )
                                }
                            }
                        }

                        // Position selector chips
                        Text("Position Beside Camera Cutout", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NotchPosition.entries.forEach { pos ->
                                FilterChip(
                                    selected = settings.notchPosition == pos,
                                    onClick = { onUpdateNotchPosition(pos) },
                                    label = { Text(pos.name.replace('_', ' ')) }
                                )
                            }
                        }

                        // Size selector chips
                        Text("Pill Size", style = MaterialTheme.typography.labelMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NotchSize.entries.forEach { size ->
                                FilterChip(
                                    selected = settings.notchSize == size,
                                    onClick = { onUpdateNotchSize(size) },
                                    label = { Text("${size.name} (${size.heightDp}dp)") }
                                )
                            }
                        }

                        // Opacity Slider
                        Text(
                            text = "Pill Opacity: ${(settings.notchOpacity * 100).toInt()}%",
                            style = MaterialTheme.typography.labelMedium
                        )
                        Slider(
                            value = settings.notchOpacity,
                            onValueChange = onUpdateNotchOpacity,
                            valueRange = 0.35f..1.0f
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Always Show (Even Outside Reels Apps)", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = settings.alwaysShowOverlay,
                                onCheckedChange = onUpdateAlwaysShowOverlay
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Hide Pill on Lockscreen", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = settings.hideOverlayOnLockscreen,
                                onCheckedChange = onUpdateHideOnLockscreen
                            )
                        }
                    }
                }
            }

            // 2. Tracked Short-Video Apps List
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Tracked Short-Video Apps",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TrackedApp.entries.forEach { app ->
                            val enabled = settings.trackedPackages.contains(app.packageName)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = app.displayName,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Checkbox(
                                    checked = enabled,
                                    onCheckedChange = { onToggleTrackedPackage(app.packageName, it) }
                                )
                            }
                        }
                    }
                }
            }

            // 3. Theme & Material You Dynamic Color
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Appearance & Theme",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ThemePreference.entries.forEach { pref ->
                                FilterChip(
                                    selected = settings.themePreference == pref,
                                    onClick = { onUpdateTheme(pref, settings.dynamicColorEnabled) },
                                    label = { Text(pref.name.replace('_', ' ')) }
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Material You Dynamic Color (Android 12+)", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = settings.dynamicColorEnabled,
                                onCheckedChange = { onUpdateTheme(settings.themePreference, it) }
                            )
                        }
                    }
                }
            }

            // 4. Debug & Scroll Simulation Console
            item {
                GlassCard(
                    borderColor = ElectricViolet.copy(alpha = 0.55f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.BugReport, contentDescription = null, tint = ElectricViolet)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Debug Console • Simulate Reel Scrolls",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "Test session building, rolling notch animations, and charts without switching apps:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TrackedApp.entries.take(4).forEach { app ->
                                OutlinedButton(
                                    onClick = {
                                        previewCount++
                                        previewPulseTs = System.currentTimeMillis()
                                        onSimulateScrollForPackage(app.packageName)
                                    }
                                ) {
                                    Text("+1 ${app.shortLabel}")
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = onSeedDemoData,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Populate 30-Day Sample History", color = ScrollGreen)
                        }
                    }
                }
            }

            // 5. Data Export (CSV), OEM Battery Guide, Privacy Policy & Reset
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Data & Privacy Management",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        OutlinedButton(
                            onClick = {
                                onExportCsv { csvContent ->
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/csv"
                                        putExtra(Intent.EXTRA_SUBJECT, "Scroll Reel History Export")
                                        putExtra(Intent.EXTRA_TEXT, csvContent)
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Export Scroll CSV"))
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.FileDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export History to CSV")
                        }

                        OutlinedButton(
                            onClick = { requestIgnoreBatteryOptimization(context) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Whitelist OEM Battery Optimization")
                        }

                        OutlinedButton(
                            onClick = { showPrivacyPolicyDialog = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Policy, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("On-Device Privacy Policy")
                        }

                        Button(
                            onClick = { showResetConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ScrollRed.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = ScrollRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reset All Scroll Data", color = ScrollRed, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(28.dp)) }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Wipe All Scroll History?") },
            text = { Text("This permanently deletes all recorded reel scroll events, sessions, and daily summaries from your device.") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirm = false
                        onResetData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ScrollRed)
                ) {
                    Text("Delete Everything", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showPrivacyPolicyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicyDialog = false },
            title = { Text("Scroll Privacy Policy") },
            text = {
                Text(
                    "1. Zero Network Transmission: Scroll does not declare android.permission.INTERNET. No data can ever leave your phone.

" +
                        "2. Accessibility Scope: Scroll listens only to TYPE_VIEW_SCROLLED and TYPE_WINDOW_CONTENT_CHANGED events inside your selected short-video apps to count vertical page changes.

" +
                        "3. Retention & Control: Detailed scroll timestamps are automatically pruned after 90 days by WorkManager, while compact daily totals are kept locally until you reset or uninstall."
                )
            },
            confirmButton = {
                Button(onClick = { showPrivacyPolicyDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}
