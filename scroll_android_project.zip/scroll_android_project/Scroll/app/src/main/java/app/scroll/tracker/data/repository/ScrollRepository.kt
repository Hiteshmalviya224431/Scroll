package app.scroll.tracker.data.repository

import app.scroll.tracker.data.SampleDataGenerator
import app.scroll.tracker.data.local.dao.ScrollDao
import app.scroll.tracker.data.local.entity.DailySummaryEntity
import app.scroll.tracker.data.local.entity.ReelScrollEventEntity
import app.scroll.tracker.data.local.entity.ScrollSessionEntity
import app.scroll.tracker.data.preferences.UserPreferencesRepository
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.domain.model.DayHeatmapPoint
import app.scroll.tracker.domain.tracker.ScrollMetricsCalculator
import app.scroll.tracker.domain.tracker.SessionTracker
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScrollRepository @Inject constructor(
    private val scrollDao: ScrollDao,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val sessionTracker = SessionTracker()
    private val _activeSessionFlow = MutableStateFlow<SessionTracker.ActiveSessionState?>(null)
    val activeSessionFlow: StateFlow<SessionTracker.ActiveSessionState?> = _activeSessionFlow.asStateFlow()

    private val _lastScrollPulseTimestamp = MutableStateFlow(0L)
    val lastScrollPulseTimestamp: StateFlow<Long> = _lastScrollPulseTimestamp.asStateFlow()

    fun observeTodayReelCount(): Flow<Int> {
        val todayIso = LocalDate.now().toString()
        return scrollDao.observeReelCountForDate(todayIso)
    }

    fun observeDashboardMetrics(): Flow<DailyDashboardMetrics> {
        val today = LocalDate.now()
        val todayIso = today.toString()
        return combine(
            preferencesRepository.settingsFlow,
            scrollDao.observeEventsForDate(todayIso),
            scrollDao.observeSessionsForDate(todayIso),
            scrollDao.observeRecentDailySummaries(60),
            _activeSessionFlow
        ) { settings, events, sessions, summaries, activeSession ->
            val validActive = activeSession?.takeIf {
                (System.currentTimeMillis() - it.lastScrollTimeMillis) <= SessionTracker.DEFAULT_SESSION_TIMEOUT_MILLIS
            }
            ScrollMetricsCalculator.computeDailyMetrics(
                todayDate = today,
                dailyGoal = settings.dailyReelGoal,
                eventsToday = events,
                sessionsToday = sessions,
                recentSummaries = summaries,
                activeSession = validActive
            )
        }
    }

    fun observe30DayHeatmap(): Flow<List<DayHeatmapPoint>> {
        return combine(
            preferencesRepository.settingsFlow,
            scrollDao.observeRecentDailySummaries(35),
            scrollDao.observeReelCountForDate(LocalDate.now().toString())
        ) { settings, summaries, todayLiveCount ->
            val today = LocalDate.now()
            val byIso = summaries.associateBy { it.dateIso }
            (29 downTo 0).map { daysAgo ->
                val date = today.minusDays(daysAgo.toLong())
                val iso = date.toString()
                val count = if (daysAgo == 0) {
                    todayLiveCount
                } else {
                    byIso[iso]?.totalReels ?: 0
                }
                DayHeatmapPoint(
                    dateIso = iso,
                    epochDay = date.toEpochDay(),
                    reelCount = count,
                    goal = byIso[iso]?.dailyGoal ?: settings.dailyReelGoal
                )
            }
        }
    }

    /**
     * Records a verified reel scroll event into Room and updates the current session & daily summary.
     * Returns the updated today count and active session state.
     */
    suspend fun recordVerifiedReelScroll(
        packageName: String,
        timestampMillis: Long = System.currentTimeMillis()
    ): Pair<Int, SessionTracker.ActiveSessionState> {
        val zone = ZoneId.systemDefault()
        val zonedDateTime = Instant.ofEpochMilli(timestampMillis).atZone(zone)
        val dateIso = zonedDateTime.toLocalDate().toString()
        val hourOfDay = zonedDateTime.hour

        val sessionResult = sessionTracker.recordScroll(packageName, timestampMillis)
        _activeSessionFlow.value = sessionResult.updatedSession
        _lastScrollPulseTimestamp.value = timestampMillis

        val event = ReelScrollEventEntity(
            timestampMillis = timestampMillis,
            dateIso = dateIso,
            hourOfDay = hourOfDay,
            packageName = packageName,
            sessionId = sessionResult.sessionId,
            dwellTimeMillis = sessionResult.dwellTimeMillis
        )
        scrollDao.insertScrollEvent(event)

        val sessionEntity = ScrollSessionEntity(
            sessionId = sessionResult.updatedSession.sessionId,
            packageName = packageName,
            dateIso = dateIso,
            startTimeMillis = sessionResult.updatedSession.startTimeMillis,
            endTimeMillis = sessionResult.updatedSession.lastScrollTimeMillis,
            reelCount = sessionResult.updatedSession.reelCount,
            totalDurationSeconds = sessionResult.updatedSession.totalDurationSeconds
        )
        scrollDao.upsertSession(sessionEntity)

        // Update live daily summary
        rollupDateSummary(zonedDateTime.toLocalDate())

        val updatedTodayEvents = scrollDao.getEventsForDate(dateIso)
        return updatedTodayEvents.size to sessionResult.updatedSession
    }

    suspend fun rollupDateSummary(date: LocalDate) {
        val dateIso = date.toString()
        val events = scrollDao.getEventsForDate(dateIso)
        val sessions = scrollDao.getSessionsForDate(dateIso)
        val settings = preferencesRepository.settingsFlow.first()

        val totalReels = events.size
        val totalSeconds = sessions.sumOf { it.totalDurationSeconds }
            .coerceAtLeast(events.sumOf { it.dwellTimeMillis } / 1000L)
        val avgSec = if (totalReels > 0) totalSeconds.toFloat() / totalReels else 0f
        val longestSec = sessions.maxOfOrNull { it.totalDurationSeconds } ?: 0L

        val hourly = IntArray(24)
        events.forEach { hourly[it.hourOfDay.coerceIn(0, 23)]++ }
        val peakHour = hourly.indices.maxByOrNull { hourly[it] } ?: 21

        val perAppString = events.groupBy { it.packageName }
            .entries
            .joinToString(",") { "${it.key}:${it.value.size}" }

        scrollDao.upsertDailySummary(
            DailySummaryEntity(
                dateIso = dateIso,
                epochDay = date.toEpochDay(),
                totalReels = totalReels,
                dailyGoal = settings.dailyReelGoal,
                totalDurationSeconds = totalSeconds,
                avgSecondsPerReel = avgSec,
                longestSessionSeconds = longestSec,
                peakHour = peakHour,
                perAppCountsJson = perAppString
            )
        )
    }

    suspend fun performMidnightRollupAndPrune() {
        val today = LocalDate.now()
        rollupDateSummary(today.minusDays(1))
        rollupDateSummary(today)

        // Keep detailed events for 90 days; keep daily_summaries forever
        val ninetyDaysAgoMillis = today.minusDays(90)
            .atStartOfDay(ZoneId.systemDefault())
            .toInstant()
            .toEpochMilli()
        scrollDao.deleteEventsOlderThan(ninetyDaysAgoMillis)
        scrollDao.deleteSessionsOlderThan(ninetyDaysAgoMillis)
    }

    suspend fun seedDemoDataIfEmpty() {
        val existing = scrollDao.getAllDailySummaries()
        if (existing.isEmpty()) {
            val settings = preferencesRepository.settingsFlow.first()
            val (events, sessions, summaries) = SampleDataGenerator.buildSeedDatabaseData(settings.dailyReelGoal)
            scrollDao.insertScrollEvents(events)
            scrollDao.upsertSessions(sessions)
            scrollDao.upsertDailySummaries(summaries)
        }
    }

    suspend fun resetAllData() {
        sessionTracker.forceEndSession()
        _activeSessionFlow.value = null
        scrollDao.resetAllData()
    }

    suspend fun exportCsvContent(): String {
        val summaries = scrollDao.getAllDailySummaries()
        val sessions = scrollDao.getSessionsForDate(LocalDate.now().toString())
        val sb = StringBuilder()
        sb.appendLine("type,date_iso,total_reels,daily_goal,total_duration_seconds,avg_seconds_per_reel,longest_session_seconds,peak_hour,details")
        for (s in summaries) {
            sb.appendLine(
                "DAILY_SUMMARY,${s.dateIso},${s.totalReels},${s.dailyGoal},${s.totalDurationSeconds},${"%.1f".format(s.avgSecondsPerReel)},${s.longestSessionSeconds},${s.peakHour},"${s.perAppCountsJson}""
            )
        }
        for (sess in sessions) {
            sb.appendLine(
                "SESSION_TODAY,${sess.dateIso},${sess.reelCount},-,${sess.totalDurationSeconds},-,-,-,"pkg=${sess.packageName};sessionId=${sess.sessionId}""
            )
        }
        return sb.toString()
    }
}
