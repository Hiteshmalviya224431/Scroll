package app.scroll.tracker.domain.model

enum class TrackedApp(
    val packageName: String,
    val displayName: String,
    val shortLabel: String,
    val accentColorHex: Long,
    val reelContainerKeywords: List<String>
) {
    INSTAGRAM_REELS(
        packageName = "com.instagram.android",
        displayName = "Instagram Reels",
        shortLabel = "Reels",
        accentColorHex = 0xFFE1306C,
        reelContainerKeywords = listOf("clips_viewer_view_pager", "reel_viewer", "clips_video_container", "Reels")
    ),
    YOUTUBE_SHORTS(
        packageName = "com.google.android.youtube",
        displayName = "YouTube Shorts",
        shortLabel = "Shorts",
        accentColorHex = 0xFFFF0033,
        reelContainerKeywords = listOf("reel_recycler", "reel_player_page_container", "shorts_player", "Shorts")
    ),
    FACEBOOK_REELS(
        packageName = "com.facebook.katana",
        displayName = "Facebook Reels",
        shortLabel = "FB Reels",
        accentColorHex = 0xFF1877F2,
        reelContainerKeywords = listOf("fb_shorts_viewer", "reels_viewer", "Reels")
    ),
    TIKTOK(
        packageName = "com.zhiliaoapp.musically",
        displayName = "TikTok",
        shortLabel = "TikTok",
        accentColorHex = 0xFF00F2FE,
        reelContainerKeywords = listOf("viewpager", "vertical_view_pager", "feed_view_pager", "For You")
    ),
    SNAPCHAT_SPOTLIGHT(
        packageName = "com.snapchat.android",
        displayName = "Snapchat Spotlight",
        shortLabel = "Spotlight",
        accentColorHex = 0xFFFFFC00,
        reelContainerKeywords = listOf("spotlight_view_pager", "spotlight_feed", "Spotlight")
    ),
    MOJ(
        packageName = "in.mohalla.video",
        displayName = "Moj",
        shortLabel = "Moj",
        accentColorHex = 0xFFFF512F,
        reelContainerKeywords = listOf("video_pager", "reel_pager", "player_view")
    ),
    JOSH(
        packageName = "com.eterno.shortvideos",
        displayName = "Josh",
        shortLabel = "Josh",
        accentColorHex = 0xFF8E2DE2,
        reelContainerKeywords = listOf("video_view_pager", "short_video_pager", "reel_container")
    );

    companion object {
        fun fromPackage(pkg: String): TrackedApp? = entries.find { it.packageName == pkg }
        val defaultPackages: Set<String> = entries.map { it.packageName }.toSet()
    }
}
