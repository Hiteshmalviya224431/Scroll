package app.scroll.tracker.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// AMOLED Black & Glassmorphic Dark Surfaces
val AmoledBlack = Color(0xFF000000)
val DeepObsidian = Color(0xFF09090F)
val GlassCardSurface = Color(0xFF12121C)
val GlassCardBorder = Color(0x26FFFFFF)

// Vibrant Electric Violet-to-Pink Accent
val ElectricViolet = Color(0xFF8B5CF6)
val NeonPink = Color(0xFFEC4899)
val SoftLavender = Color(0xFFC4B5FD)

// Threshold Semantic Colors (WCAG >= 4.5:1 against AMOLED black)
val ScrollGreen = Color(0xFF00E676)
val ScrollAmber = Color(0xFFFFB300)
val ScrollRed = Color(0xFFFF1744)

// Text Colors
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFFA1A1AA)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)

val ElectricAccentBrush = Brush.linearGradient(
    colors = listOf(ElectricViolet, NeonPink)
)
