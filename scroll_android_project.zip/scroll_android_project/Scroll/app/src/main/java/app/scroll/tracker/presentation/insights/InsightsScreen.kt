package app.scroll.tracker.presentation.insights

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Height
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.TrendingDown
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import app.scroll.tracker.data.SampleDataGenerator
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.domain.model.DayHeatmapPoint
import app.scroll.tracker.domain.model.SessionItem
import app.scroll.tracker.presentation.components.GlassCard
import app.scroll.tracker.presentation.today.formatMinutesSeconds
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollAmber
import app.scroll.tracker.ui.theme.ScrollGreen
import app.scroll.tracker.ui.theme.ScrollRed
import app.scroll.tracker.ui.theme.ScrollTheme
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

@Composable
fun InsightsScreen(
    metrics: DailyDashboardMetrics,
    heatmap30Days: List<DayHeatmapPoint>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Comparisons Row: vs Yesterday & vs Weekly Average
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ComparisonDeltaCard(
                    title = "vs. Yesterday",
                    percentDelta = metrics.vsYesterdayPercentDelta,
                    modifier = Modifier.weight(1f)
                )
                ComparisonDeltaCard(
                    title = "vs. 7-Day Avg",
                    percentDelta = metrics.vsWeeklyAvgPercentDelta,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 24-Hour Scroll Activity Bar Chart
        item {
            HourlyActivityChartCard(
                hourlyCounts = metrics.hourlyCounts,
                peakHour = metrics.peakHourOfDay
            )
        }

        // 7-Day Weekly Bar Chart
        item {
            WeeklyBarChartCard(
                days = heatmap30Days.takeLast(7)
            )
        }

        // 30-Day GitHub-Style Calendar Heatmap
        item {
            CalendarHeatmap30DayCard(
                days = heatmap30Days
            )
        }

        // Fun Equivalents Section
        item {
            FunStatsSection(
                metersScrolled = metrics.metersScrolledToday,
                movieHours = metrics.equivalentMovieHours,
                longestSessionSeconds = metrics.longestSessionSeconds,
                longestSessionReels = metrics.longestSessionReels
            )
        }

        // Daily Session Timeline Header
        item {
            Text(
                text = "Today's Session Timeline (60s timeout)",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (metrics.sessionsToday.isEmpty()) {
            item {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "No completed sessions recorded today yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(metrics.sessionsToday, key = { it.sessionId }) { session ->
                SessionTimelineRow(session = session)
            }
        }

        item { Spacer(modifier = Modifier.height(28.dp)) }
    }
}

@Composable
private fun ComparisonDeltaCard(
    title: String,
    percentDelta: Int,
    modifier: Modifier = Modifier
) {
    val isLower = percentDelta <= 0
    val badgeColor = if (isLower) ScrollGreen else ScrollRed
    val sign = if (percentDelta > 0) "+" else ""

    GlassCard(modifier = modifier, contentPadding = 16.dp) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isLower) Icons.Rounded.TrendingDown else Icons.Rounded.TrendingUp,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$sign$percentDelta%",
                    style = MaterialTheme.typography.headlineMedium,
                    color = badgeColor
                )
            }
            Text(
                text = if (isLower) "Fewer reels scrolled" else "More reels scrolled",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HourlyActivityChartCard(
    hourlyCounts: List<Int>,
    peakHour: Int
) {
    val maxCount = (hourlyCounts.maxOrNull() ?: 1).coerceAtLeast(1)

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "24-Hour Scroll Rhythm",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Peak hour: ${formatHourLabel(peakHour)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NeonPink
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                val barCount = 24
                val spacing = 4.dp.toPx()
                val totalSpacing = spacing * (barCount - 1)
                val barWidth = ((size.width - totalSpacing) / barCount).coerceAtLeast(4f)

                hourlyCounts.forEachIndexed { hour, count ->
                    val ratio = (count.toFloat() / maxCount.toFloat()).coerceIn(0.05f, 1f)
                    val barHeight = size.height * ratio
                    val x = hour * (barWidth + spacing)
                    val y = size.height - barHeight

                    val brush = if (hour == peakHour && count > 0) {
                        Brush.verticalGradient(listOf(NeonPink, ElectricViolet))
                    } else {
                        Brush.verticalGradient(
                            listOf(
                                ElectricViolet.copy(alpha = 0.85f),
                                ElectricViolet.copy(alpha = 0.35f)
                            )
                        )
                    }

                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("12a", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("6a", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("12p", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("6p", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("11p", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun WeeklyBarChartCard(days: List<DayHeatmapPoint>) {
    val maxReels = (days.maxOfOrNull { it.reelCount } ?: 100).coerceAtLeast(1)

    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column {
            Text(
                text = "Last 7 Days",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                days.forEach { day ->
                    val fraction = (day.reelCount.toFloat() / maxReels.toFloat()).coerceIn(0.08f, 1f)
                    val barColor = when {
                        day.reelCount <= day.goal * 0.6f -> ScrollGreen
                        day.reelCount <= day.goal -> ElectricViolet
                        else -> ScrollRed
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text(
                            text = day.reelCount.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(22.dp)
                                .height((82 * fraction).dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(barColor)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = day.dateIso.takeLast(2),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarHeatmap30DayCard(days: List<DayHeatmapPoint>) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "30-Day Consistency Heatmap",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "GitHub Style",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricViolet
                )
            }
            Spacer(modifier = Modifier.height(14.dp))

            val rows = days.chunked(10)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { point ->
                            val cellColor = when {
                                point.reelCount == 0 -> Color(0xFF1E1E2C)
                                point.reelCount < 50 -> ScrollGreen.copy(alpha = 0.75f)
                                point.reelCount <= point.goal -> ElectricViolet.copy(alpha = 0.85f)
                                point.reelCount <= 150 -> ScrollAmber.copy(alpha = 0.85f)
                                else -> ScrollRed.copy(alpha = 0.9f)
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(cellColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = point.reelCount.toString(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FunStatsSection(
    metersScrolled: Float,
    movieHours: Float,
    longestSessionSeconds: Long,
    longestSessionReels: Int
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "Tangible Perspectives",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            FunStatRow(
                icon = Icons.Rounded.Straighten,
                title = "You scrolled ~${"%.1f".format(metersScrolled)} meters of screen today",
                subtitle = "Based on 14.5 cm vertical swipe travel per reel"
            )
            FunStatRow(
                icon = Icons.Rounded.Movie,
                title = "Equivalent to ${"%.2f".format(movieHours)} hours of feature films",
                subtitle = "Longest single binge session: $longestSessionReels reels (${formatMinutesSeconds(longestSessionSeconds)})"
            )
            FunStatRow(
                icon = Icons.Rounded.Height,
                title = "Stacked height: ${"%.1f".format(metersScrolled)}m (${"%.1f".format(metersScrolled / 3.0f)} stories high)",
                subtitle = "If every reel today were stacked end-to-end vertically"
            )
        }
    }
}

@Composable
private fun FunStatRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(ElectricViolet.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ElectricViolet,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SessionTimelineRow(session: SessionItem) {
    val formatter = DateTimeFormatter.ofPattern("h:mm a")
    val startText = Instant.ofEpochMilli(session.startTimeMillis)
        .atZone(ZoneId.systemDefault())
        .format(formatter)

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = 16.dp
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = session.appDisplayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Started at $startText • Duration ${formatMinutesSeconds(session.durationSeconds)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(ElectricViolet.copy(alpha = 0.18f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "${session.reelCount} reels",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricViolet
                )
            }
        }
    }
}

private fun formatHourLabel(hour: Int): String {
    return when {
        hour == 0 -> "12:00 AM"
        hour < 12 -> "$hour:00 AM"
        hour == 12 -> "12:00 PM"
        else -> "${hour - 12}:00 PM"
    }
}

@Preview(showBackground = true)
@Composable
private fun InsightsScreenPreview() {
    ScrollTheme {
        InsightsScreen(
            metrics = SampleDataGenerator.previewDashboardMetrics(),
            heatmap30Days = SampleDataGenerator.preview30DayHeatmap()
        )
    }
}
