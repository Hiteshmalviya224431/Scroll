package app.scroll.tracker.presentation.today

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Celebration
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scroll.tracker.data.SampleDataGenerator
import app.scroll.tracker.domain.model.AppUsageSplit
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.presentation.components.GlassCard
import app.scroll.tracker.presentation.components.GoalConfettiOverlay
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollAmber
import app.scroll.tracker.ui.theme.ScrollGreen
import app.scroll.tracker.ui.theme.ScrollRed
import app.scroll.tracker.ui.theme.ScrollTheme

@Composable
fun TodayScreen(
    metrics: DailyDashboardMetrics,
    isAccessibilityServiceActive: Boolean,
    onOpenAccessibilitySetup: () -> Unit,
    onSimulateScrollClick: () -> Unit
) {
    val view = LocalView.current
    var confettiTrigger by remember { mutableIntStateOf(0) }

    // Haptic tick when reel count increments
    LaunchedEffect(metrics.totalReelsToday) {
        if (metrics.totalReelsToday > 0) {
            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Service status banner if Accessibility Service isn't enabled yet
            if (!isAccessibilityServiceActive) {
                item {
                    GlassCard(
                        borderColor = NeonPink.copy(alpha = 0.6f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenAccessibilitySetup() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Enable Live Notch Counter",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NeonPink
                                )
                                Text(
                                    text = "Tap to turn on Scroll Accessibility Service so swipes are tracked automatically.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(
                                imageVector = Icons.Rounded.Bolt,
                                contentDescription = "Enable Accessibility",
                                tint = NeonPink,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }
            }

            // Live "Scrolling Now" indicator when a session is active
            if (metrics.isActiveSessionNow) {
                item {
                    LiveScrollingNowBanner(
                        appName = metrics.activeSessionApp ?: "Reels",
                        sessionReels = metrics.activeSessionReels
                    )
                }
            }

            // Hero Animated Circular Ring with Soft Glow
            item {
                HeroCircularRingCard(
                    totalReels = metrics.totalReelsToday,
                    dailyGoal = metrics.dailyGoal,
                    onCelebrateUnderGoal = {
                        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        confettiTrigger++
                    }
                )
            }

            // 3-Column Key Metrics Row: Time Spent, Avg / Reel, Streak Under Goal
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetricStatCard(
                        icon = Icons.Rounded.Schedule,
                        label = "Time Spent",
                        value = formatMinutesSeconds(metrics.totalTimeSeconds),
                        accentColor = ElectricViolet,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        icon = Icons.Rounded.Speed,
                        label = "Avg / Reel",
                        value = "${"%.1f".format(metrics.avgSecondsPerReel)}s",
                        accentColor = NeonPink,
                        modifier = Modifier.weight(1f)
                    )
                    MetricStatCard(
                        icon = Icons.Rounded.LocalFireDepartment,
                        label = "Goal Streak",
                        value = "${metrics.currentStreakDays}d",
                        accentColor = ScrollGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Scroll Personality Chip Card
            item {
                ScrollPersonalityCard(
                    emoji = metrics.personality.emoji,
                    title = metrics.personality.title,
                    subtitle = metrics.personality.subtitle
                )
            }

            // Per-App Breakdown Section Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Per-App Split",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "+1 Demo Swipe",
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricViolet,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ElectricViolet.copy(alpha = 0.15f))
                            .clickable { onSimulateScrollClick() }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            if (metrics.appSplits.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No reels scrolled yet today. Open a short-video app or tap '+1 Demo Swipe' above to test the live counter.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(metrics.appSplits, key = { it.packageName }) { split ->
                    PerAppUsageCard(split = split)
                }
            }

            item { Spacer(modifier = Modifier.height(28.dp)) }
        }

        // Confetti micro-interaction when staying under daily goal
        GoalConfettiOverlay(triggerKey = confettiTrigger)
    }
}

@Composable
private fun LiveScrollingNowBanner(
    appName: String,
    sessionReels: Int
) {
    val infiniteTransition = rememberInfiniteTransition(label = "liveDotTransition")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x2200E676))
            .border(1.dp, ScrollGreen.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
            .padding(vertical = 10.dp, horizontal = 16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(ScrollGreen.copy(alpha = pulseAlpha))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "Scrolling now • $appName ($sessionReels reels in active session)",
            style = MaterialTheme.typography.labelMedium,
            color = ScrollGreen
        )
    }
}

@Composable
private fun HeroCircularRingCard(
    totalReels: Int,
    dailyGoal: Int,
    onCelebrateUnderGoal: () -> Unit
) {
    val rawProgress = if (dailyGoal > 0) totalReels.toFloat() / dailyGoal.toFloat() else 0f
    val animatedSweep by animateFloatAsState(
        targetValue = rawProgress.coerceIn(0f, 1f) * 360f,
        animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing),
        label = "heroRingSweep"
    )

    val statusColor = when {
        totalReels < 50 -> ScrollGreen
        totalReels < 150 -> ScrollAmber
        else -> ScrollRed
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = "Today's reel count: $totalReels out of $dailyGoal daily goal"
            },
        contentPadding = 28.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(230.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokePx = 20.dp.toPx()
                    val glowRadius = size.minDimension / 2f

                    // Soft radial glow around the main ring
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                ElectricViolet.copy(alpha = 0.25f),
                                NeonPink.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = glowRadius
                        ),
                        radius = glowRadius
                    )

                    val arcInset = strokePx / 2f + 8.dp.toPx()
                    val arcSize = Size(size.width - arcInset * 2, size.height - arcInset * 2)

                    // Background track ring
                    drawArc(
                        color = Color(0xFF222232),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = Offset(arcInset, arcInset),
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )

                    // Foreground vibrant gradient arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            colors = listOf(ElectricViolet, NeonPink, statusColor, ElectricViolet)
                        ),
                        startAngle = -90f,
                        sweepAngle = animatedSweep,
                        useCenter = false,
                        topLeft = Offset(arcInset, arcInset),
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "REELS TODAY",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    AnimatedContent(
                        targetState = totalReels,
                        transitionSpec = {
                            (slideInVertically { h -> h } + fadeIn())
                                .togetherWith(slideOutVertically { h -> -h } + fadeOut())
                        },
                        label = "heroRollingCount"
                    ) { count ->
                        Text(
                            text = count.toString(),
                            style = MaterialTheme.typography.displayLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "of $dailyGoal daily goal",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            val isUnderGoal = totalReels <= dailyGoal
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (isUnderGoal) ScrollGreen.copy(alpha = 0.14f)
                        else ScrollRed.copy(alpha = 0.14f)
                    )
                    .clickable(enabled = isUnderGoal) { onCelebrateUnderGoal() }
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Celebration,
                    contentDescription = null,
                    tint = if (isUnderGoal) ScrollGreen else ScrollRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isUnderGoal) {
                        "${(dailyGoal - totalReels).coerceAtLeast(0)} reels remaining under goal • Tap to celebrate"
                    } else {
                        "${totalReels - dailyGoal} reels over daily limit"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isUnderGoal) ScrollGreen else ScrollRed,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun MetricStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier,
        contentPadding = 14.dp
    ) {
        Column(horizontalAlignment = Alignment.Start) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ScrollPersonalityCard(
    emoji: String,
    title: String,
    subtitle: String
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = 18.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ElectricViolet.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 24.sp)
            }
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = NeonPink,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SCROLL PERSONALITY",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonPink
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PerAppUsageCard(split: AppUsageSplit) {
    val barColor = Color(split.accentColorHex)
    val animatedFraction by animateFloatAsState(
        targetValue = split.fractionOfTotal.coerceIn(0.04f, 1f),
        animationSpec = tween(durationMillis = 600),
        label = "appSplitBar"
    )

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = 16.dp
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.PlayCircleFilled,
                        contentDescription = split.displayName,
                        tint = barColor,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = split.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = formatMinutesSeconds(split.durationSeconds),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${split.reelCount} reels",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${(split.fractionOfTotal * 100).toInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                        color = barColor
                    )
                }
            }

            // Mini progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF232334))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedFraction)
                        .height(7.dp)
                        .clip(CircleShape)
                        .background(barColor)
                )
            }
        }
    }
}

fun formatMinutesSeconds(totalSeconds: Long): String {
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return when {
        minutes >= 60 -> "${minutes / 60}h ${minutes % 60}m"
        minutes > 0 -> "${minutes}m ${seconds}s"
        else -> "${seconds}s"
    }
}

@Preview(showBackground = true)
@Composable
private fun TodayScreenPreview() {
    ScrollTheme {
        TodayScreen(
            metrics = SampleDataGenerator.previewDashboardMetrics(),
            isAccessibilityServiceActive = true,
            onOpenAccessibilitySetup = {},
            onSimulateScrollClick = {}
        )
    }
}
