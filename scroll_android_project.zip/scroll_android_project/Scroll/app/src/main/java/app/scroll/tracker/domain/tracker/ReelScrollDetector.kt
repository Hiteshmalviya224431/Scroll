package app.scroll.tracker.domain.tracker

/**
 * Pure, unit-testable detector that determines whether an Accessibility scroll/content event
 * represents a genuine vertical reel page change.
 *
 * Rules:
 * 1. Only counts when the app is in the foreground and on its Reels/Shorts vertical feed screen.
 * 2. Detects vertical ViewPager2 / RecyclerView item index advances OR significant vertical page snaps.
 * 3. Applies a strict debounce (default 400ms) so multi-frame settling events count as 1 swipe.
 */
class ReelScrollDetector(
    private val debounceMillis: Long = DEFAULT_DEBOUNCE_MILLIS
) {
    data class ScrollCandidate(
        val packageName: String,
        val timestampMillis: Long,
        val isForeground: Boolean,
        val isInReelsScreen: Boolean,
        val className: String?,
        val fromIndex: Int,
        val toIndex: Int,
        val itemCount: Int,
        val scrollDeltaY: Int
    )

    private var lastCountedTimestampMillis: Long = -1L
    private val lastPageIndexByPackage = mutableMapOf<String, Int>()

    @Synchronized
    fun onScrollCandidate(candidate: ScrollCandidate): Boolean {
        if (!candidate.isForeground || !candidate.isInReelsScreen) {
            return false
        }

        // Enforce 400ms debounce window
        if (lastCountedTimestampMillis > 0 &&
            (candidate.timestampMillis - lastCountedTimestampMillis) < debounceMillis
        ) {
            return false
        }

        val isVerticalPagerWidget = candidate.className?.let { cls ->
            VERTICAL_PAGER_CLASSES.any { keyword -> cls.contains(keyword, ignoreCase = true) }
        } ?: true

        if (!isVerticalPagerWidget) {
            return false
        }

        val previousIndex = lastPageIndexByPackage[candidate.packageName]

        // Case A: Accessibility event reports valid adapter position (fromIndex) that advanced
        val indexChanged = if (candidate.fromIndex >= 0) {
            val targetIndex = if (candidate.toIndex > candidate.fromIndex) candidate.toIndex else candidate.fromIndex
            if (previousIndex == null) {
                lastPageIndexByPackage[candidate.packageName] = targetIndex
                true
            } else if (targetIndex != previousIndex) {
                lastPageIndexByPackage[candidate.packageName] = targetIndex
                true
            } else {
                false
            }
        } else {
            // Case B: ViewPager2 / custom vertical pager doesn't populate fromIndex, check vertical swipe delta
            candidate.scrollDeltaY >= MIN_VERTICAL_SWIPE_DELTA_PX
        }

        if (indexChanged) {
            lastCountedTimestampMillis = candidate.timestampMillis
            return true
        }

        return false
    }

    @Synchronized
    fun resetPackageState(packageName: String) {
        lastPageIndexByPackage.remove(packageName)
    }

    @Synchronized
    fun resetAll() {
        lastCountedTimestampMillis = -1L
        lastPageIndexByPackage.clear()
    }

    companion object {
        const val DEFAULT_DEBOUNCE_MILLIS = 400L
        const val MIN_VERTICAL_SWIPE_DELTA_PX = 220

        private val VERTICAL_PAGER_CLASSES = listOf(
            "ViewPager",
            "ViewPager2",
            "RecyclerView",
            "ScrollView",
            "FrameLayout",
            "ViewGroup"
        )
    }
}
