package app.scroll.tracker.presentation.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.GlassCardBorder
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollAmber
import app.scroll.tracker.ui.theme.ScrollGreen
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Rounded 24dp card with subtle glassmorphism surface & specular border.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderColor: Color = GlassCardBorder,
    contentPadding: Dp = 20.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val surfaceColor = MaterialTheme.colorScheme.surface
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        surfaceColor.copy(alpha = 0.92f),
                        surfaceColor.copy(alpha = 0.78f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderColor,
                        borderColor.copy(alpha = 0.05f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .padding(contentPadding),
        content = content
    )
}

/**
 * Celebratory confetti burst overlay when staying under the daily goal.
 */
@Composable
fun GoalConfettiOverlay(
    triggerKey: Int,
    modifier: Modifier = Modifier
) {
    if (triggerKey <= 0) return
    val progress = remember(triggerKey) { Animatable(0f) }

    LaunchedEffect(triggerKey) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 1600, easing = LinearEasing)
        )
    }

    val particles = remember(triggerKey) {
        val colors = listOf(ElectricViolet, NeonPink, ScrollGreen, ScrollAmber, Color.Cyan)
        val rng = Random(triggerKey)
        List(36) {
            ConfettiParticle(
                angleRad = rng.nextDouble(0.0, Math.PI * 2).toFloat(),
                speed = rng.nextFloat() * 480f + 120f,
                color = colors[it % colors.size],
                radius = rng.nextFloat() * 6f + 5f
            )
        }
    }

    if (progress.value < 1f) {
        Canvas(modifier = modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.3f)
            val t = progress.value
            val alpha = (1f - t).coerceIn(0f, 1f)
            particles.forEach { p ->
                val dx = cos(p.angleRad) * p.speed * t
                val dy = sin(p.angleRad) * p.speed * t + (320f * t * t)
                drawCircle(
                    color = p.color.copy(alpha = alpha),
                    radius = p.radius,
                    center = Offset(center.x + dx, center.y + dy)
                )
            }
        }
    }
}

private data class ConfettiParticle(
    val angleRad: Float,
    val speed: Float,
    val color: Color,
    val radius: Float
)
