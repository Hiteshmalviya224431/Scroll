package app.scroll.tracker.domain.tracker

import java.util.UUID

/**
 * Pure, unit-testable session state machine.
 * A session groups consecutive reel scrolls and automatically expires after 60 seconds
 * of inactivity or when the user switches to a different tracked app.
 */
class SessionTracker(
    private val sessionTimeoutMillis: Long = DEFAULT_SESSION_TIMEOUT_MILLIS,
    private val idGenerator: () -> String = { UUID.randomUUID().toString() }
) {
    data class ActiveSessionState(
        val sessionId: String,
        val packageName: String,
        val startTimeMillis: Long,
        val lastScrollTimeMillis: Long,
        val reelCount: Int,
        val totalDurationSeconds: Long
    )

    data class RecordedScrollResult(
        val sessionId: String,
        val isNewSession: Boolean,
        val dwellTimeMillis: Long,
        val updatedSession: ActiveSessionState
    )

    private var currentSession: ActiveSessionState? = null

    @Synchronized
    fun recordScroll(packageName: String, timestampMillis: Long): RecordedScrollResult {
        val existing = currentSession
        val isExpired = existing == null ||
            existing.packageName != packageName ||
            (timestampMillis - existing.lastScrollTimeMillis) > sessionTimeoutMillis

        return if (isExpired || existing == null) {
            val newSessionId = idGenerator()
            val defaultFirstReelSeconds = 6L
            val freshSession = ActiveSessionState(
                sessionId = newSessionId,
                packageName = packageName,
                startTimeMillis = timestampMillis,
                lastScrollTimeMillis = timestampMillis,
                reelCount = 1,
                totalDurationSeconds = defaultFirstReelSeconds
            )
            currentSession = freshSession
            RecordedScrollResult(
                sessionId = newSessionId,
                isNewSession = true,
                dwellTimeMillis = defaultFirstReelSeconds * 1000L,
                updatedSession = freshSession
            )
        } else {
            val dwellMillis = (timestampMillis - existing.lastScrollTimeMillis)
                .coerceIn(400L, sessionTimeoutMillis)
            val elapsedSeconds = ((timestampMillis - existing.startTimeMillis) / 1000L)
                .coerceAtLeast(existing.totalDurationSeconds + (dwellMillis / 1000L))
            val updated = existing.copy(
                lastScrollTimeMillis = timestampMillis,
                reelCount = existing.reelCount + 1,
                totalDurationSeconds = elapsedSeconds
            )
            currentSession = updated
            RecordedScrollResult(
                sessionId = updated.sessionId,
                isNewSession = false,
                dwellTimeMillis = dwellMillis,
                updatedSession = updated
            )
        }
    }

    @Synchronized
    fun getActiveSession(nowMillis: Long): ActiveSessionState? {
        val existing = currentSession ?: return null
        return if ((nowMillis - existing.lastScrollTimeMillis) <= sessionTimeoutMillis) {
            existing
        } else {
            currentSession = null
            null
        }
    }

    @Synchronized
    fun forceEndSession() {
        currentSession = null
    }

    companion object {
        const val DEFAULT_SESSION_TIMEOUT_MILLIS = 60_000L
    }
}
