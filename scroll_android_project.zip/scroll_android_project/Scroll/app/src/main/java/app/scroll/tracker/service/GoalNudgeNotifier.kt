package app.scroll.tracker.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import app.scroll.tracker.MainActivity
import app.scroll.tracker.R
import dagger.hilt.android.qualifiers.ApplicationContext
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoalNudgeNotifier @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var last80NotifiedDate: LocalDate? = null
    private var last100NotifiedDate: LocalDate? = null

    init {
        createChannel()
    }

    private fun createChannel() {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Scroll Goal Nudges",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Gentle nudges when you reach 80% and 100% of your daily reel limit"
        }
        nm.createNotificationChannel(channel)
    }

    fun checkAndNotify(
        todayReels: Int,
        dailyGoal: Int,
        nudge80Enabled: Boolean,
        nudge100Enabled: Boolean
    ) {
        if (dailyGoal <= 0) return
        val today = LocalDate.now()
        val threshold80 = (dailyGoal * 0.8f).toInt().coerceAtLeast(1)

        if (nudge100Enabled && todayReels >= dailyGoal && last100NotifiedDate != today) {
            last100NotifiedDate = today
            postNotification(
                id = 1002,
                title = "Daily Reel Limit Reached ($todayReels / $dailyGoal)",
                body = "You've hit 100% of your daily goal. Ready to give your eyes a rest?"
            )
        } else if (nudge80Enabled && todayReels >= threshold80 && todayReels < dailyGoal && last80NotifiedDate != today) {
            last80NotifiedDate = today
            postNotification(
                id = 1001,
                title = "Heads up: 80% of Daily Reel Goal ($todayReels / $dailyGoal)",
                body = "Only ${dailyGoal - todayReels} reels left before your daily goal."
            )
        }
    }

    private fun postNotification(id: Int, title: String, body: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_scroll_logo)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        runCatching { nm.notify(id, notification) }
    }

    companion object {
        private const val CHANNEL_ID = "scroll_goal_nudges"
    }
}
