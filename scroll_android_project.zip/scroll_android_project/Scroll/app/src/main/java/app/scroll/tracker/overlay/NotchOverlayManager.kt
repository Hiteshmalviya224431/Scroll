package app.scroll.tracker.overlay

import android.app.KeyguardManager
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scroll.tracker.domain.model.NotchPosition
import app.scroll.tracker.domain.model.NotchSize
import app.scroll.tracker.domain.model.ScrollSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages the tiny non-touchable live counter pill ("▶ 128") positioned right next to the
 * camera notch/cutout using TYPE_ACCESSIBILITY_OVERLAY and WindowInsets.displayCutout.
 */
@Singleton
class NotchOverlayManager @Inject constructor() {

    private var windowManager: WindowManager? = null
    private var composeView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private val _reelCountFlow = MutableStateFlow(0)
    private val _pulseTriggerFlow = MutableStateFlow(0L)
    private val _settingsFlow = MutableStateFlow(ScrollSettings())
    private val _isVisibleFlow = MutableStateFlow(false)

    fun attachToAccessibilityContext(serviceContext: Context) {
        if (composeView != null) return
        val wm = serviceContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = dpToPx(serviceContext, 8)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        layoutParams = params

        val owner = OverlayLifecycleOwner().apply { onCreate() }
        lifecycleOwner = owner

        val view = ComposeView(serviceContext).apply {
            owner.attachToView(this)
            setContent {
                val count by _reelCountFlow.collectAsState()
                val pulseTs by _pulseTriggerFlow.collectAsState()
                val settings by _settingsFlow.collectAsState()
                val visible by _isVisibleFlow.collectAsState()

                if (visible) {
                    NotchPillComposable(
                        count = count,
                        pulseTimestamp = pulseTs,
                        settings = settings
                    )
                }
            }
            // Listen for WindowInsets so we can align precisely next to the camera cutout
            setOnApplyWindowInsetsListener { v, insets ->
                repositionBesideCutout(serviceContext, v)
                insets
            }
        }
        composeView = view

        runCatching {
            wm.addView(view, params)
            view.post { repositionBesideCutout(serviceContext, view) }
        }
    }

    fun updateState(
        context: Context,
        count: Int,
        pulseTimestamp: Long,
        settings: ScrollSettings,
        isInTrackedApp: Boolean
    ) {
        _reelCountFlow.value = count
        if (pulseTimestamp > 0L) {
            _pulseTriggerFlow.value = pulseTimestamp
        }
        val positionChanged = _settingsFlow.value.notchPosition != settings.notchPosition ||
            _settingsFlow.value.notchSize != settings.notchSize
        _settingsFlow.value = settings

        val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isLocked = keyguardManager?.isKeyguardLocked == true

        val shouldShow = when {
            settings.hideOverlayOnLockscreen && isLocked -> false
            settings.alwaysShowOverlay -> true
            else -> isInTrackedApp
        }
        _isVisibleFlow.value = shouldShow

        if (positionChanged) {
            composeView?.let { v ->
                v.post { repositionBesideCutout(context, v) }
            }
        }
    }

    private fun repositionBesideCutout(context: Context, view: android.view.View) {
        val wm = windowManager ?: return
        val params = layoutParams ?: return
        val settings = _settingsFlow.value
        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels

        val cutoutRect: Rect? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            view.rootWindowInsets?.displayCutout?.boundingRects?.firstOrNull()
        } else {
            null
        }

        val estimatedPillWidthPx = dpToPx(context, 62)
        val estimatedPillHeightPx = dpToPx(context, settings.notchSize.heightDp)
        val gapPx = dpToPx(context, 6)

        if (cutoutRect != null && !cutoutRect.isEmpty && settings.notchPosition != NotchPosition.TOP_CENTER) {
            val centeredY = (cutoutRect.centerY() - (estimatedPillHeightPx / 2))
                .coerceAtLeast(dpToPx(context, 4))
            params.y = centeredY
            params.x = when (settings.notchPosition) {
                NotchPosition.LEFT -> (cutoutRect.left - estimatedPillWidthPx - gapPx)
                    .coerceAtLeast(dpToPx(context, 8))
                NotchPosition.RIGHT -> (cutoutRect.right + gapPx)
                    .coerceAtMost(screenWidth - estimatedPillWidthPx - dpToPx(context, 8))
                NotchPosition.TOP_CENTER -> (screenWidth - estimatedPillWidthPx) / 2
            }
        } else {
            // Fallback when device has no camera cutout or user selected TOP_CENTER
            params.y = dpToPx(context, 6)
            params.x = when (settings.notchPosition) {
                NotchPosition.LEFT -> dpToPx(context, 16)
                NotchPosition.RIGHT -> screenWidth - estimatedPillWidthPx - dpToPx(context, 16)
                NotchPosition.TOP_CENTER -> (screenWidth - estimatedPillWidthPx) / 2
            }
        }

        runCatching {
            wm.updateViewLayout(view, params)
        }
    }

    fun detach() {
        val wm = windowManager
        val view = composeView
        if (wm != null && view != null) {
            runCatching { wm.removeViewImmediate(view) }
        }
        lifecycleOwner?.onDestroy()
        lifecycleOwner = null
        composeView = null
        windowManager = null
    }

    private fun dpToPx(context: Context, dp: Int): Int {
        return (dp * context.resources.displayMetrics.density).toInt()
    }
}

@Composable
fun NotchPillComposable(
    count: Int,
    pulseTimestamp: Long,
    settings: ScrollSettings,
    modifier: Modifier = Modifier
) {
    // Threshold color shift: Green (<50), Amber (50-150), Red (150+)
    val targetAccentColor = when {
        count < settings.greenThreshold -> Color(0xFF00E676) // Vibrant Emerald Green
        count < settings.amberThreshold -> Color(0xFFFFB300) // Warm Amber
        else -> Color(0xFFFF1744)                            // Electric Crimson Red
    }

    val animatedAccentColor by animateColorAsState(
        targetValue = targetAccentColor,
        animationSpec = tween(durationMillis = 350),
        label = "notchThresholdColor"
    )

    // Subtle scale pulse on every counted scroll
    val pulseScale = remember { Animatable(1f) }
    LaunchedEffect(pulseTimestamp) {
        if (pulseTimestamp > 0L) {
            pulseScale.snapTo(1.16f)
            pulseScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        }
    }

    Box(
        modifier = modifier
            .scale(pulseScale.value)
            .alpha(settings.notchOpacity)
            .height(settings.notchSize.heightDp.dp)
            .clip(CircleShape)
            .background(Color(0xE608080C))
            .border(
                width = 1.dp,
                color = animatedAccentColor.copy(alpha = 0.72f),
                shape = CircleShape
            )
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.PlayArrow,
                contentDescription = null,
                tint = animatedAccentColor,
                modifier = Modifier.size((settings.notchSize.fontSizeSp + 2).dp)
            )

            // Rolling number tick-up animation
            AnimatedContent(
                targetState = count,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInVertically { height -> height } + fadeIn(tween(180)))
                            .togetherWith(slideOutVertically { height -> -height } + fadeOut(tween(180)))
                    } else {
                        (slideInVertically { height -> -height } + fadeIn(tween(180)))
                            .togetherWith(slideOutVertically { height -> height } + fadeOut(tween(180)))
                    }
                },
                label = "rollingCounter"
            ) { targetCount ->
                Text(
                    text = targetCount.toString(),
                    color = Color.White,
                    fontSize = settings.notchSize.fontSizeSp.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }
    }
}
