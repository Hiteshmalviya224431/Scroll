package app.scroll.tracker.domain.model

enum class NotchPosition {
    LEFT, RIGHT, TOP_CENTER
}

enum class NotchSize(val heightDp: Int, val fontSizeSp: Int) {
    COMPACT(20, 11),
    STANDARD(24, 12),
    LARGE(28, 14)
}

enum class ThemePreference {
    AMOLED_DARK, SYSTEM, LIGHT
}

data class ScrollSettings(
    val hasCompletedOnboarding: Boolean = false,
    val hasAcceptedAccessibilityDisclosure: Boolean = false,
    val dailyReelGoal: Int = 100,
    val greenThreshold: Int = 50,
    val amberThreshold: Int = 150,
    val notchPosition: NotchPosition = NotchPosition.RIGHT,
    val notchSize: NotchSize = NotchSize.STANDARD,
    val notchOpacity: Float = 0.92f,
    val alwaysShowOverlay: Boolean = false,
    val hideOverlayOnLockscreen: Boolean = true,
    val trackedPackages: Set<String> = TrackedApp.defaultPackages,
    val nudgeAt80Percent: Boolean = true,
    val nudgeAt100Percent: Boolean = true,
    val mindfulBreakEnabled: Boolean = true,
    val mindfulBreakReelsThreshold: Int = 35,
    val mindfulBreakMinutesThreshold: Int = 15,
    val quietHoursEnabled: Boolean = false,
    val quietStartHour: Int = 23,
    val quietEndHour: Int = 7,
    val themePreference: ThemePreference = ThemePreference.AMOLED_DARK,
    val dynamicColorEnabled: Boolean = false
)

enum class ScrollPersonality(
    val title: String,
    val subtitle: String,
    val emoji: String
) {
    MINDFUL_MINIMALIST(
        title = "Mindful Minimalist",
        subtitle = "Short, intentional check-ins well under your daily limit",
        emoji = "🧘"
    ),
    NIGHT_OWL_SCROLLER(
        title = "Night Owl Scroller",
        subtitle = "Most of your reels happen after 10 PM",
        emoji = "🦉"
    ),
    BINGE_BURSTER(
        title = "Binge Burster",
        subtitle = "Long high-velocity sessions once you start swiping",
        emoji = "⚡"
    ),
    MICRO_SNACKER(
        title = "Micro Snacker",
        subtitle = "Frequent 2–3 minute bursts spread throughout the day",
        emoji = "🍿"
    ),
    SPEED_SWIPER(
        title = "Speed Swiper",
        subtitle = "Under 6 seconds per reel — rapid dopamine checks",
        emoji = "🚀"
    )
}

data class AppUsageSplit(
    val app: TrackedApp?,
    val packageName: String,
    val displayName: String,
    val reelCount: Int,
    val durationSeconds: Long,
    val fractionOfTotal: Float,
    val accentColorHex: Long
)

data class SessionItem(
    val sessionId: String,
    val packageName: String,
    val appDisplayName: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val reelCount: Int,
    val durationSeconds: Long
)

data class DailyDashboardMetrics(
    val dateEpochDay: Long,
    val totalReelsToday: Int,
    val dailyGoal: Int,
    val totalTimeSeconds: Long,
    val avgSecondsPerReel: Float,
    val longestSessionSeconds: Long,
    val longestSessionReels: Int,
    val peakHourOfDay: Int, // 0..23
    val currentStreakDays: Int,
    val personality: ScrollPersonality,
    val appSplits: List<AppUsageSplit>,
    val hourlyCounts: List<Int>, // 24 items
    val sessionsToday: List<SessionItem>,
    val isActiveSessionNow: Boolean,
    val activeSessionApp: String?,
    val activeSessionReels: Int,
    val metersScrolledToday: Float,
    val equivalentMovieHours: Float,
    val stackedHeightMeters: Float,
    val vsYesterdayPercentDelta: Int,
    val vsWeeklyAvgPercentDelta: Int
)

data class DayHeatmapPoint(
    val dateIso: String, // YYYY-MM-DD
    val epochDay: Long,
    val reelCount: Int,
    val goal: Int
)
