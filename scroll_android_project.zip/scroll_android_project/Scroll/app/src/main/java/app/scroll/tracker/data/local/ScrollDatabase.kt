package app.scroll.tracker.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import app.scroll.tracker.data.local.dao.ScrollDao
import app.scroll.tracker.data.local.entity.DailySummaryEntity
import app.scroll.tracker.data.local.entity.ReelScrollEventEntity
import app.scroll.tracker.data.local.entity.ScrollSessionEntity

@Database(
    entities = [
        ReelScrollEventEntity::class,
        ScrollSessionEntity::class,
        DailySummaryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ScrollDatabase : RoomDatabase() {
    abstract fun scrollDao(): ScrollDao
}
