package app.scroll.tracker.di

import android.content.Context
import androidx.room.Room
import app.scroll.tracker.data.local.ScrollDatabase
import app.scroll.tracker.data.local.dao.ScrollDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideScrollDatabase(
        @ApplicationContext context: Context
    ): ScrollDatabase {
        return Room.databaseBuilder(
            context,
            ScrollDatabase::class.java,
            "scroll_tracker.db"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    @Singleton
    fun provideScrollDao(database: ScrollDatabase): ScrollDao {
        return database.scrollDao()
    }
}
