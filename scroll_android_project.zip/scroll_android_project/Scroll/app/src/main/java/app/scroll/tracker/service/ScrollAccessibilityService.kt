package app.scroll.tracker.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import app.scroll.tracker.data.preferences.UserPreferencesRepository
import app.scroll.tracker.data.repository.ScrollRepository
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.domain.model.TrackedApp
import app.scroll.tracker.domain.tracker.ReelScrollDetector
import app.scroll.tracker.overlay.MindfulBreakOverlayManager
import app.scroll.tracker.overlay.NotchOverlayManager
import app.scroll.tracker.widget.ScrollGlanceWidget
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.time.LocalTime
import javax.inject.Inject
import kotlin.math.abs

/**
 * Pure event-driven AccessibilityService that listens to TYPE_VIEW_SCROLLED and
 * TYPE_WINDOW_CONTENT_CHANGED across configured short-video apps, verifies the foreground
 * screen is a vertical Reels/Shorts feed, debounces swipes (400ms), persists events to Room,
 * and drives the live TYPE_ACCESSIBILITY_OVERLAY pill next to the camera cutout.
 */
@AndroidEntryPoint
class ScrollAccessibilityService : AccessibilityService() {

    @Inject lateinit var scrollRepository: ScrollRepository
    @Inject lateinit var preferencesRepository: UserPreferencesRepository
    @Inject lateinit var notchOverlayManager: NotchOverlayManager
    @Inject lateinit var mindfulBreakOverlayManager: MindfulBreakOverlayManager
    @Inject lateinit var goalNudgeNotifier: GoalNudgeNotifier

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val reelScrollDetector = ReelScrollDetector(debounceMillis = 400L)

    private var currentSettings = ScrollSettings()
    private var latestTodayCount = 0
    private var currentForegroundPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceRunning = true
        notchOverlayManager.attachToAccessibilityContext(this)

        serviceScope.launch {
            preferencesRepository.settingsFlow.collectLatest { settings ->
                currentSettings = settings
                refreshOverlayVisibility()
            }
        }

        serviceScope.launch {
            scrollRepository.observeTodayReelCount().collectLatest { count ->
                latestTodayCount = count
                refreshOverlayVisibility()
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // Ignore our own overlay events
        if (pkg == packageName) return

        currentForegroundPackage = pkg
        val isTrackedPackage = currentSettings.trackedPackages.contains(pkg)

        if (!isTrackedPackage || isWithinQuietHours(currentSettings)) {
            refreshOverlayVisibility(pulseTimestamp = 0L)
            return
        }

        val eventType = event.eventType
        if (eventType != AccessibilityEvent.TYPE_VIEW_SCROLLED &&
            eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            return
        }

        // Only count TYPE_VIEW_SCROLLED primarily, or TYPE_WINDOW_CONTENT_CHANGED when a vertical pager snaps
        val isInReelsScreen = verifyIsInReelsScreen(pkg, event)
        if (!isInReelsScreen) {
            refreshOverlayVisibility(pulseTimestamp = 0L)
            return
        }

        val candidate = ReelScrollDetector.ScrollCandidate(
            packageName = pkg,
            timestampMillis = System.currentTimeMillis(),
            isForeground = true,
            isInReelsScreen = true,
            className = event.className?.toString(),
            fromIndex = event.fromIndex,
            toIndex = event.toIndex,
            itemCount = event.itemCount,
            scrollDeltaY = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) abs(event.scrollDeltaY) else 300
        )

        // Ensure we only trigger on genuine scroll events or indexed pager changes
        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && event.fromIndex < 0) {
            return
        }

        val counted = reelScrollDetector.onScrollCandidate(candidate)
        if (counted) {
            serviceScope.launch(Dispatchers.IO) {
                val (newTodayCount, activeSession) = scrollRepository.recordVerifiedReelScroll(
                    packageName = pkg,
                    timestampMillis = candidate.timestampMillis
                )
                latestTodayCount = newTodayCount

                launch(Dispatchers.Main) {
                    notchOverlayManager.updateState(
                        context = this@ScrollAccessibilityService,
                        count = newTodayCount,
                        pulseTimestamp = candidate.timestampMillis,
                        settings = currentSettings,
                        isInTrackedApp = true
                    )

                    goalNudgeNotifier.checkAndNotify(
                        todayReels = newTodayCount,
                        dailyGoal = currentSettings.dailyReelGoal,
                        nudge80Enabled = currentSettings.nudgeAt80Percent,
                        nudge100Enabled = currentSettings.nudgeAt100Percent
                    )

                    if (currentSettings.mindfulBreakEnabled &&
                        mindfulBreakOverlayManager.shouldTriggerPrompt(
                            sessionReels = activeSession.reelCount,
                            sessionDurationSeconds = activeSession.totalDurationSeconds,
                            reelsThreshold = currentSettings.mindfulBreakReelsThreshold,
                            minutesThreshold = currentSettings.mindfulBreakMinutesThreshold
                        )
                    ) {
                        val appLabel = TrackedApp.fromPackage(pkg)?.displayName ?: pkg
                        mindfulBreakOverlayManager.showMindfulBreak(
                            serviceContext = this@ScrollAccessibilityService,
                            sessionReels = activeSession.reelCount,
                            sessionMinutes = (activeSession.totalDurationSeconds / 60L).toInt(),
                            appName = appLabel
                        )
                    }
                }

                // Update Glance home screen widget
                ScrollGlanceWidget.updateAllWidgets(applicationContext)
            }
        } else {
            refreshOverlayVisibility(pulseTimestamp = 0L)
        }
    }

    /**
     * Heuristic verification that the tracked app is currently displaying its vertical Reels/Shorts feed
     * rather than DM messages, profile grid, or settings.
     */
    private fun verifyIsInReelsScreen(pkg: String, event: AccessibilityEvent): Boolean {
        val trackedApp = TrackedApp.fromPackage(pkg)
        // Dedicated short-video apps (TikTok, Moj, Josh) are primarily vertical reel feeds
        if (trackedApp == TrackedApp.TIKTOK ||
            trackedApp == TrackedApp.MOJ ||
            trackedApp == TrackedApp.JOSH
        ) {
            return true
        }

        val sourceNode = event.source
        if (sourceNode != null) {
            val viewId = sourceNode.viewIdResourceName ?: ""
            val desc = sourceNode.contentDescription?.toString() ?: ""
            if (trackedApp != null && trackedApp.reelContainerKeywords.any { kw ->
                    viewId.contains(kw, ignoreCase = true) || desc.contains(kw, ignoreCase = true)
                }
            ) {
                return true
            }
        }

        // Inspect active window root for selected Reels/Shorts tab or vertical ViewPager container
        val rootNode: AccessibilityNodeInfo = rootInActiveWindow ?: return true
        return searchNodeTreeForReelsKeywords(
            node = rootNode,
            keywords = trackedApp?.reelContainerKeywords ?: listOf("reel", "short", "spotlight"),
            maxDepth = 5
        )
    }

    private fun searchNodeTreeForReelsKeywords(
        node: AccessibilityNodeInfo?,
        keywords: List<String>,
        maxDepth: Int
    ): Boolean {
        if (node == null || maxDepth < 0) return false
        val id = node.viewIdResourceName ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if (keywords.any { kw -> id.contains(kw, ignoreCase = true) }) {
            return true
        }
        if (node.isSelected && keywords.any { kw -> desc.contains(kw, ignoreCase = true) }) {
            return true
        }
        val childCount = node.childCount.coerceAtMost(12)
        for (i in 0 until childCount) {
            if (searchNodeTreeForReelsKeywords(node.getChild(i), keywords, maxDepth - 1)) {
                return true
            }
        }
        return false
    }

    private fun isWithinQuietHours(settings: ScrollSettings): Boolean {
        if (!settings.quietHoursEnabled) return false
        val nowHour = LocalTime.now().hour
        val start = settings.quietStartHour
        val end = settings.quietEndHour
        return if (start <= end) {
            nowHour in start until end
        } else {
            // Spans midnight (e.g., 23:00 to 07:00)
            nowHour >= start || nowHour < end
        }
    }

    private fun refreshOverlayVisibility(pulseTimestamp: Long = 0L) {
        val inTracked = currentForegroundPackage != null &&
            currentSettings.trackedPackages.contains(currentForegroundPackage) &&
            !isWithinQuietHours(currentSettings)
        notchOverlayManager.updateState(
            context = this,
            count = latestTodayCount,
            pulseTimestamp = pulseTimestamp,
            settings = currentSettings,
            isInTrackedApp = inTracked
        )
    }

    override fun onInterrupt() {
        // Required override for AccessibilityService
    }

    override fun onDestroy() {
        isServiceRunning = false
        notchOverlayManager.detach()
        mindfulBreakOverlayManager.dismiss()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile
        var isServiceRunning: Boolean = false
            private set
    }
}
