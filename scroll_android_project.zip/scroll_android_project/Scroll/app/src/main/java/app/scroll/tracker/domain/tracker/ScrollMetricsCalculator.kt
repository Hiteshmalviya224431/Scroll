package app.scroll.tracker.domain.tracker

import app.scroll.tracker.data.local.entity.DailySummaryEntity
import app.scroll.tracker.data.local.entity.ReelScrollEventEntity
import app.scroll.tracker.data.local.entity.ScrollSessionEntity
import app.scroll.tracker.domain.model.AppUsageSplit
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.domain.model.ScrollPersonality
import app.scroll.tracker.domain.model.SessionItem
import app.scroll.tracker.domain.model.TrackedApp
import java.time.LocalDate
import kotlin.math.roundToInt

object ScrollMetricsCalculator {

    // Physical height of an average 6.5" smartphone viewport in meters (~14.5 cm = 0.145 m)
    private const val METERS_PER_REEL_SWIPE = 0.145f
    // Average feature film length in seconds (110 minutes)
    private const val SECONDS_PER_HOUR = 3600f

    fun computeDailyMetrics(
        todayDate: LocalDate,
        dailyGoal: Int,
        eventsToday: List<ReelScrollEventEntity>,
        sessionsToday: List<ScrollSessionEntity>,
        recentSummaries: List<DailySummaryEntity>,
        activeSession: SessionTracker.ActiveSessionState?
    ): DailyDashboardMetrics {
        val totalReels = eventsToday.size
        val totalTimeMillis = eventsToday.sumOf { it.dwellTimeMillis.coerceIn(500L, 60_000L) }
        val totalTimeSeconds = (totalTimeMillis / 1000L).coerceAtLeast(
            sessionsToday.sumOf { it.totalDurationSeconds }
        )

        val avgSeconds = if (totalReels > 0) {
            (totalTimeSeconds.toFloat() / totalReels.toFloat())
        } else {
            0f
        }

        val longestSessionEntity = sessionsToday.maxByOrNull { it.totalDurationSeconds }
        val longestSessionSeconds = longestSessionEntity?.totalDurationSeconds ?: 0L
        val longestSessionReels = longestSessionEntity?.reelCount ?: 0

        val hourlyCounts = MutableList(24) { 0 }
        for (event in eventsToday) {
            val h = event.hourOfDay.coerceIn(0, 23)
            hourlyCounts[h] = hourlyCounts[h] + 1
        }
        val peakHour = if (totalReels > 0) {
            hourlyCounts.indices.maxByOrNull { hourlyCounts[it] } ?: 21
        } else {
            21
        }

        // Per-app split
        val groupedByPkg = eventsToday.groupBy { it.packageName }
        val appSplits = groupedByPkg.map { (pkg, pkgEvents) ->
            val trackedApp = TrackedApp.fromPackage(pkg)
            val count = pkgEvents.size
            val durSec = pkgEvents.sumOf { it.dwellTimeMillis } / 1000L
            AppUsageSplit(
                app = trackedApp,
                packageName = pkg,
                displayName = trackedApp?.displayName ?: pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() },
                reelCount = count,
                durationSeconds = durSec,
                fractionOfTotal = if (totalReels > 0) count.toFloat() / totalReels.toFloat() else 0f,
                accentColorHex = trackedApp?.accentColorHex ?: 0xFF9D4EDD
            )
        }.sortedByDescending { it.reelCount }

        val sessionItems = sessionsToday.map { s ->
            val tracked = TrackedApp.fromPackage(s.packageName)
            SessionItem(
                sessionId = s.sessionId,
                packageName = s.packageName,
                appDisplayName = tracked?.displayName ?: s.packageName,
                startTimeMillis = s.startTimeMillis,
                endTimeMillis = s.endTimeMillis,
                reelCount = s.reelCount,
                durationSeconds = s.totalDurationSeconds
            )
        }

        val personality = classifyPersonality(
            totalReels = totalReels,
            dailyGoal = dailyGoal,
            avgSecondsPerReel = avgSeconds,
            longestSessionReels = longestSessionReels,
            hourlyCounts = hourlyCounts,
            sessionCount = sessionsToday.size
        )

        val streakDays = computeUnderGoalStreak(
            todayDate = todayDate,
            todayReels = totalReels,
            dailyGoal = dailyGoal,
            recentSummaries = recentSummaries
        )

        val yesterdayIso = todayDate.minusDays(1).toString()
        val yesterdaySummary = recentSummaries.find { it.dateIso == yesterdayIso }
        val vsYesterdayDelta = if (yesterdaySummary != null && yesterdaySummary.totalReels > 0) {
            (((totalReels - yesterdaySummary.totalReels).toFloat() / yesterdaySummary.totalReels) * 100f).roundToInt()
        } else {
            0
        }

        val last7Days = recentSummaries.filter { it.dateIso != todayDate.toString() }.take(7)
        val weeklyAvg = if (last7Days.isNotEmpty()) {
            last7Days.map { it.totalReels }.average().toFloat()
        } else {
            dailyGoal.toFloat()
        }
        val vsWeeklyAvgDelta = if (weeklyAvg > 0f) {
            (((totalReels - weeklyAvg) / weeklyAvg) * 100f).roundToInt()
        } else {
            0
        }

        val metersScrolled = totalReels * METERS_PER_REEL_SWIPE
        val movieHours = totalTimeSeconds / SECONDS_PER_HOUR

        return DailyDashboardMetrics(
            dateEpochDay = todayDate.toEpochDay(),
            totalReelsToday = totalReels,
            dailyGoal = dailyGoal,
            totalTimeSeconds = totalTimeSeconds,
            avgSecondsPerReel = avgSeconds,
            longestSessionSeconds = longestSessionSeconds,
            longestSessionReels = longestSessionReels,
            peakHourOfDay = peakHour,
            currentStreakDays = streakDays,
            personality = personality,
            appSplits = appSplits,
            hourlyCounts = hourlyCounts,
            sessionsToday = sessionItems,
            isActiveSessionNow = activeSession != null,
            activeSessionApp = activeSession?.packageName?.let { TrackedApp.fromPackage(it)?.displayName ?: it },
            activeSessionReels = activeSession?.reelCount ?: 0,
            metersScrolledToday = metersScrolled,
            equivalentMovieHours = movieHours,
            stackedHeightMeters = metersScrolled,
            vsYesterdayPercentDelta = vsYesterdayDelta,
            vsWeeklyAvgPercentDelta = vsWeeklyAvgDelta
        )
    }

    private fun classifyPersonality(
        totalReels: Int,
        dailyGoal: Int,
        avgSecondsPerReel: Float,
        longestSessionReels: Int,
        hourlyCounts: List<Int>,
        sessionCount: Int
    ): ScrollPersonality {
        if (totalReels == 0) return ScrollPersonality.MINDFUL_MINIMALIST

        val lateNightReels = hourlyCounts.slice(22..23).sum() + hourlyCounts.slice(0..3).sum()
        if (lateNightReels.toFloat() / totalReels >= 0.42f) {
            return ScrollPersonality.NIGHT_OWL_SCROLLER
        }
        if (longestSessionReels >= 45) {
            return ScrollPersonality.BINGE_BURSTER
        }
        if (avgSecondsPerReel in 0.5f..5.8f && totalReels >= 20) {
            return ScrollPersonality.SPEED_SWIPER
        }
        if (sessionCount >= 6 && longestSessionReels < 25) {
            return ScrollPersonality.MICRO_SNACKER
        }
        return if (totalReels <= (dailyGoal * 0.75f)) {
            ScrollPersonality.MINDFUL_MINIMALIST
        } else {
            ScrollPersonality.BINGE_BURSTER
        }
    }

    private fun computeUnderGoalStreak(
        todayDate: LocalDate,
        todayReels: Int,
        dailyGoal: Int,
        recentSummaries: List<DailySummaryEntity>
    ): Int {
        val byDate = recentSummaries.associateBy { it.dateIso }
        var streak = if (todayReels <= dailyGoal) 1 else 0
        if (streak == 0) return 0

        var cursor = todayDate.minusDays(1)
        for (i in 1..60) {
            val summary = byDate[cursor.toString()] ?: break
            if (summary.totalReels <= summary.dailyGoal) {
                streak++
                cursor = cursor.minusDays(1)
            } else {
                break
            }
        }
        return streak
    }
}
