package app.scroll.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Today
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.hilt.navigation.compose.hiltViewModel
import app.scroll.tracker.presentation.MainViewModel
import app.scroll.tracker.presentation.goals.GoalsScreen
import app.scroll.tracker.presentation.insights.InsightsScreen
import app.scroll.tracker.presentation.onboarding.AccessibilityProminentDisclosureDialog
import app.scroll.tracker.presentation.onboarding.OnboardingScreen
import app.scroll.tracker.presentation.onboarding.openAccessibilitySettings
import app.scroll.tracker.presentation.settings.SettingsScreen
import app.scroll.tracker.presentation.today.TodayScreen
import app.scroll.tracker.service.ScrollAccessibilityService
import app.scroll.tracker.ui.theme.ScrollTheme
import dagger.hilt.android.AndroidEntryPoint

enum class MainTab(val label: String, val icon: ImageVector) {
    TODAY("Today", Icons.Rounded.Today),
    INSIGHTS("Insights", Icons.Rounded.BarChart),
    GOALS("Goals", Icons.Rounded.Flag)
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = hiltViewModel()
            val settings by viewModel.settingsState.collectAsState()

            ScrollTheme(
                themePreference = settings.themePreference,
                dynamicColor = settings.dynamicColorEnabled
            ) {
                ScrollAppRoot(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScrollAppRoot(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settingsState.collectAsState()
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val heatmap30Days by viewModel.heatmap30Days.collectAsState()

    var selectedTab by rememberSaveable { mutableStateOf(MainTab.TODAY) }
    var showSettingsScreen by rememberSaveable { mutableStateOf(false) }
    var showDisclosureModal by rememberSaveable { mutableStateOf(false) }

    if (!settings.hasCompletedOnboarding) {
        OnboardingScreen(
            hasAcceptedDisclosure = settings.hasAcceptedAccessibilityDisclosure,
            onAcceptDisclosure = { viewModel.setAccessibilityDisclosureAccepted() },
            onCompleteOnboarding = { viewModel.setOnboardingCompleted() }
        )
        return
    }

    if (showSettingsScreen) {
        SettingsScreen(
            settings = settings,
            todayCount = metrics.totalReelsToday,
            onBack = { showSettingsScreen = false },
            onUpdateNotchPosition = viewModel::updateNotchPosition,
            onUpdateNotchSize = viewModel::updateNotchSize,
            onUpdateNotchOpacity = viewModel::updateNotchOpacity,
            onUpdateAlwaysShowOverlay = viewModel::updateAlwaysShowOverlay,
            onUpdateHideOnLockscreen = viewModel::updateHideOnLockscreen,
            onToggleTrackedPackage = viewModel::toggleTrackedPackage,
            onUpdateTheme = viewModel::updateTheme,
            onExportCsv = viewModel::exportCsv,
            onResetData = viewModel::resetAllData,
            onSimulateScrollForPackage = viewModel::simulateReelScroll,
            onSeedDemoData = viewModel::seedDemoData
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Scroll",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black
                    )
                },
                actions = {
                    IconButton(onClick = { showSettingsScreen = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Open Settings"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
            ) {
                MainTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = selectedTab,
            modifier = Modifier.padding(innerPadding),
            label = "mainTabTransition"
        ) { tab ->
            when (tab) {
                MainTab.TODAY -> TodayScreen(
                    metrics = metrics,
                    isAccessibilityServiceActive = ScrollAccessibilityService.isServiceRunning,
                    onOpenAccessibilitySetup = {
                        if (!settings.hasAcceptedAccessibilityDisclosure) {
                            showDisclosureModal = true
                        } else {
                            openAccessibilitySettings(context)
                        }
                    },
                    onSimulateScrollClick = { viewModel.simulateReelScroll() }
                )
                MainTab.INSIGHTS -> InsightsScreen(
                    metrics = metrics,
                    heatmap30Days = heatmap30Days
                )
                MainTab.GOALS -> GoalsScreen(
                    settings = settings,
                    onUpdateDailyGoal = viewModel::updateDailyGoal,
                    onUpdateThresholds = viewModel::updateThresholds,
                    onUpdateNudges = viewModel::updateNudges,
                    onUpdateMindfulBreak = viewModel::updateMindfulBreak,
                    onUpdateQuietHours = viewModel::updateQuietHours
                )
            }
        }
    }

    if (showDisclosureModal) {
        AccessibilityProminentDisclosureDialog(
            onAccept = {
                showDisclosureModal = false
                viewModel.setAccessibilityDisclosureAccepted()
                openAccessibilitySettings(context)
            },
            onDecline = { showDisclosureModal = false }
        )
    }
}
