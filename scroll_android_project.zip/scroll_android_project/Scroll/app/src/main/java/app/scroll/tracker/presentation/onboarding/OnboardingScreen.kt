package app.scroll.tracker.presentation.onboarding

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.overlay.NotchPillComposable
import app.scroll.tracker.presentation.components.GlassCard
import app.scroll.tracker.service.ScrollAccessibilityService
import app.scroll.tracker.ui.theme.ElectricAccentBrush
import app.scroll.tracker.ui.theme.ElectricViolet
import app.scroll.tracker.ui.theme.NeonPink
import app.scroll.tracker.ui.theme.ScrollGreen

@Composable
fun OnboardingScreen(
    hasAcceptedDisclosure: Boolean,
    onAcceptDisclosure: () -> Unit,
    onCompleteOnboarding: () -> Unit
) {
    val context = LocalContext.current
    var currentPage by remember { mutableIntStateOf(0) }
    var showDisclosureDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 16.dp)
        ) {
            repeat(3) { index ->
                Box(
                    modifier = Modifier
                        .height(6.dp)
                        .width(if (index == currentPage) 32.dp else 12.dp)
                        .clip(CircleShape)
                        .background(
                            if (index == currentPage) ElectricViolet
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }

        AnimatedContent(
            targetState = currentPage,
            label = "onboardingPage"
        ) { page ->
            when (page) {
                0 -> OnboardingPageOne()
                1 -> OnboardingPageTwo()
                else -> OnboardingPageThree(
                    context = context,
                    hasAcceptedDisclosure = hasAcceptedDisclosure,
                    onRequestAccessibilitySetup = {
                        if (!hasAcceptedDisclosure) {
                            showDisclosureDialog = true
                        } else {
                            openAccessibilitySettings(context)
                        }
                    },
                    onRequestBatteryOptimizationWhitelist = {
                        requestIgnoreBatteryOptimization(context)
                    }
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (currentPage > 0) {
                TextButton(onClick = { currentPage-- }) {
                    Text("Back", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                Spacer(modifier = Modifier.width(64.dp))
            }

            Button(
                onClick = {
                    if (currentPage < 2) {
                        currentPage++
                    } else {
                        onCompleteOnboarding()
                    }
                },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .height(54.dp)
                    .background(ElectricAccentBrush, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = if (currentPage < 2) "Continue" else "Enter Scroll Dashboard",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }

    if (showDisclosureDialog) {
        AccessibilityProminentDisclosureDialog(
            onAccept = {
                showDisclosureDialog = false
                onAcceptDisclosure()
                openAccessibilitySettings(context)
            },
            onDecline = {
                showDisclosureDialog = false
            }
        )
    }
}

@Composable
private fun OnboardingPageOne() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 24.dp)
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = 24.dp
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "LIVE CAMERA CUTOUT PILL",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricViolet
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(1.5.dp, Color(0xFF27272A), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    NotchPillComposable(
                        count = 42,
                        pulseTimestamp = 0L,
                        settings = ScrollSettings()
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Color shifts from Green (<50) to Amber (50–150) to Red (150+) as you swipe.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = "See Every Reel You Scroll in Real Time",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Short-form feeds are designed to make time disappear. Scroll places a tiny, non-touchable live counter right beside your camera notch whenever you're in Instagram Reels, YouTube Shorts, TikTok, or Spotlight.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun OnboardingPageTwo() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 24.dp)
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(ElectricViolet.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = "100% On-Device Privacy",
                tint = ElectricViolet,
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = "100% On-Device. Zero Network Access.",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "Scroll does not even request the Android INTERNET permission in its manifest. Every swipe timestamp stays strictly in your local Room database.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PrivacyBulletRow("No accounts, no cloud sync, no analytics SDKs")
                PrivacyBulletRow("Never reads text messages, passwords, or personal inputs")
                PrivacyBulletRow("Export your data to CSV or wipe it in one tap anytime")
            }
        }
    }
}

@Composable
private fun PrivacyBulletRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Rounded.CheckCircle,
            contentDescription = null,
            tint = ScrollGreen,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun OnboardingPageThree(
    context: Context,
    hasAcceptedDisclosure: Boolean,
    onRequestAccessibilitySetup: () -> Unit,
    onRequestBatteryOptimizationWhitelist: () -> Unit
) {
    val isServiceActive = ScrollAccessibilityService.isServiceRunning
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    val isIgnoringBatteryOpt = powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 16.dp)
    ) {
        Text(
            text = "Guided Permission Setup",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Scroll uses Android's Accessibility Service for both swipe counting and drawing the notch pill — so no separate overlay permission is needed.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(20.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Visibility,
                        contentDescription = null,
                        tint = NeonPink
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Why We Need Accessibility Service",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "1. Detect when a vertical video pager (Reels/Shorts/TikTok) snaps to the next video.\n2. Display the non-touchable TYPE_ACCESSIBILITY_OVERLAY counter pill beside your camera notch.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = onRequestAccessibilitySetup,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isServiceActive) "Accessibility Service Active ✓"
                        else if (hasAcceptedDisclosure) "Open Accessibility Settings"
                        else "Review Disclosure & Enable Service",
                        color = if (isServiceActive) ScrollGreen else ElectricViolet,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.BatteryChargingFull,
                        contentDescription = null,
                        tint = ScrollGreen
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Prevent OEM Background Kill",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "Samsung, Xiaomi, OnePlus, and Pixel devices may pause Accessibility services under aggressive battery savers. Whitelist Scroll for uninterrupted counting.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = onRequestBatteryOptimizationWhitelist,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isIgnoringBatteryOpt) "Battery Whitelisted ✓" else "Whitelist Battery Optimization",
                        color = if (isIgnoringBatteryOpt) ScrollGreen else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun AccessibilityProminentDisclosureDialog(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDecline,
        icon = {
            Icon(
                imageVector = Icons.Rounded.Security,
                contentDescription = null,
                tint = ElectricViolet
            )
        },
        title = {
            Text(
                text = "Accessibility Service Disclosure",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "Scroll uses the Android AccessibilityService API (TYPE_VIEW_SCROLLED and TYPE_WINDOW_CONTENT_CHANGED) solely to:\n\n• Detect when you swipe vertically between short-form videos in your selected apps (Instagram Reels, YouTube Shorts, TikTok, Facebook Reels, Snapchat Spotlight, Moj, and Josh).\n• Show a tiny, non-touchable live counter pill next to your camera cutout.\n\nPrivacy Guarantee:\nScroll does NOT read personal text, messages, passwords, or keystrokes. Scroll has no INTERNET permission — 100% of your scroll counts remain privately on your device.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            Button(onClick = onAccept) {
                Text("I Agree & Enable")
            }
        },
        dismissButton = {
            TextButton(onClick = onDecline) {
                Text("Not Now")
            }
        }
    )
}

fun openAccessibilitySettings(context: Context) {
    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(intent) }
}

fun requestIgnoreBatteryOptimization(context: Context) {
    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
        data = Uri.parse("package:${context.packageName}")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    runCatching { context.startActivity(intent) }
}
