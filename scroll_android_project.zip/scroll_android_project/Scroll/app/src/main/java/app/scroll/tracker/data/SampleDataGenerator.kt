package app.scroll.tracker.data

import app.scroll.tracker.data.local.entity.DailySummaryEntity
import app.scroll.tracker.data.local.entity.ReelScrollEventEntity
import app.scroll.tracker.data.local.entity.ScrollSessionEntity
import app.scroll.tracker.domain.model.AppUsageSplit
import app.scroll.tracker.domain.model.DailyDashboardMetrics
import app.scroll.tracker.domain.model.DayHeatmapPoint
import app.scroll.tracker.domain.model.ScrollPersonality
import app.scroll.tracker.domain.model.SessionItem
import app.scroll.tracker.domain.model.TrackedApp
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID
import kotlin.random.Random

object SampleDataGenerator {

    fun previewDashboardMetrics(): DailyDashboardMetrics {
        val hourly = listOf(
            4, 0, 0, 0, 0, 0,
            2, 8, 14, 6, 3, 5,
            18, 11, 4, 2, 7, 12,
            15, 22, 28, 34, 19, 8
        )
        return DailyDashboardMetrics(
            dateEpochDay = LocalDate.now().toEpochDay(),
            totalReelsToday = 84,
            dailyGoal = 100,
            totalTimeSeconds = 1140L, // 19m
            avgSecondsPerReel = 13.5f,
            longestSessionSeconds = 480L,
            longestSessionReels = 36,
            peakHourOfDay = 21,
            currentStreakDays = 5,
            personality = ScrollPersonality.NIGHT_OWL_SCROLLER,
            appSplits = listOf(
                AppUsageSplit(
                    app = TrackedApp.INSTAGRAM_REELS,
                    packageName = TrackedApp.INSTAGRAM_REELS.packageName,
                    displayName = "Instagram Reels",
                    reelCount = 46,
                    durationSeconds = 620L,
                    fractionOfTotal = 0.55f,
                    accentColorHex = TrackedApp.INSTAGRAM_REELS.accentColorHex
                ),
                AppUsageSplit(
                    app = TrackedApp.YOUTUBE_SHORTS,
                    packageName = TrackedApp.YOUTUBE_SHORTS.packageName,
                    displayName = "YouTube Shorts",
                    reelCount = 26,
                    durationSeconds = 355L,
                    fractionOfTotal = 0.31f,
                    accentColorHex = TrackedApp.YOUTUBE_SHORTS.accentColorHex
                ),
                AppUsageSplit(
                    app = TrackedApp.TIKTOK,
                    packageName = TrackedApp.TIKTOK.packageName,
                    displayName = "TikTok",
                    reelCount = 12,
                    durationSeconds = 165L,
                    fractionOfTotal = 0.14f,
                    accentColorHex = TrackedApp.TIKTOK.accentColorHex
                )
            ),
            hourlyCounts = hourly,
            sessionsToday = listOf(
                SessionItem(
                    sessionId = "s1",
                    packageName = TrackedApp.INSTAGRAM_REELS.packageName,
                    appDisplayName = "Instagram Reels",
                    startTimeMillis = System.currentTimeMillis() - 3_600_000L,
                    endTimeMillis = System.currentTimeMillis() - 3_120_000L,
                    reelCount = 36,
                    durationSeconds = 480L
                ),
                SessionItem(
                    sessionId = "s2",
                    packageName = TrackedApp.YOUTUBE_SHORTS.packageName,
                    appDisplayName = "YouTube Shorts",
                    startTimeMillis = System.currentTimeMillis() - 14_400_000L,
                    endTimeMillis = System.currentTimeMillis() - 14_045_000L,
                    reelCount = 26,
                    durationSeconds = 355L
                ),
                SessionItem(
                    sessionId = "s3",
                    packageName = TrackedApp.TIKTOK.packageName,
                    appDisplayName = "TikTok",
                    startTimeMillis = System.currentTimeMillis() - 28_800_000L,
                    endTimeMillis = System.currentTimeMillis() - 28_635_000L,
                    reelCount = 12,
                    durationSeconds = 165L
                )
            ),
            isActiveSessionNow = true,
            activeSessionApp = "Instagram Reels",
            activeSessionReels = 14,
            metersScrolledToday = 12.18f,
            equivalentMovieHours = 0.32f,
            stackedHeightMeters = 12.18f,
            vsYesterdayPercentDelta = -14,
            vsWeeklyAvgPercentDelta = -8
        )
    }

    fun preview30DayHeatmap(goal: Int = 100): List<DayHeatmapPoint> {
        val today = LocalDate.now()
        val random = Random(42)
        return (29 downTo 0).map { daysAgo ->
            val date = today.minusDays(daysAgo.toLong())
            val count = when {
                daysAgo == 0 -> 84
                daysAgo % 7 == 0 -> random.nextInt(110, 175)
                else -> random.nextInt(28, 98)
            }
            DayHeatmapPoint(
                dateIso = date.toString(),
                epochDay = date.toEpochDay(),
                reelCount = count,
                goal = goal
            )
        }
    }

    /**
     * Generates 30 days of historical summaries + realistic sessions and events for today
     * so first-time users or reviewers can explore rich charts immediately.
     */
    fun buildSeedDatabaseData(dailyGoal: Int = 100): Triple<List<ReelScrollEventEntity>, List<ScrollSessionEntity>, List<DailySummaryEntity>> {
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val random = Random(2026)

        val events = mutableListOf<ReelScrollEventEntity>()
        val sessions = mutableListOf<ScrollSessionEntity>()
        val summaries = mutableListOf<DailySummaryEntity>()

        // Past 29 days summaries
        for (daysAgo in 29 downTo 1) {
            val date = today.minusDays(daysAgo.toLong())
            val totalReels = if (daysAgo % 6 == 0) random.nextInt(115, 165) else random.nextInt(38, 96)
            val avgSec = random.nextInt(9, 17).toFloat()
            val totalDur = (totalReels * avgSec).toLong()
            val igCount = (totalReels * 0.52f).toInt()
            val ytCount = (totalReels * 0.31f).toInt()
            val ttCount = (totalReels - igCount - ytCount).coerceAtLeast(0)

            summaries.add(
                DailySummaryEntity(
                    dateIso = date.toString(),
                    epochDay = date.toEpochDay(),
                    totalReels = totalReels,
                    dailyGoal = dailyGoal,
                    totalDurationSeconds = totalDur,
                    avgSecondsPerReel = avgSec,
                    longestSessionSeconds = (totalDur * 0.42f).toLong(),
                    peakHour = if (daysAgo % 2 == 0) 22 else 13,
                    perAppCountsJson = "${TrackedApp.INSTAGRAM_REELS.packageName}:$igCount,${TrackedApp.YOUTUBE_SHORTS.packageName}:$ytCount,${TrackedApp.TIKTOK.packageName}:$ttCount"
                )
            )
        }

        // Today's sample sessions (4 realistic bursts)
        val todayStartMillis = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val sampleSpecs = listOf(
            Triple(TrackedApp.INSTAGRAM_REELS.packageName, 8, 16),   // 8 AM, 16 reels
            Triple(TrackedApp.YOUTUBE_SHORTS.packageName, 13, 22),   // 1 PM, 22 reels
            Triple(TrackedApp.TIKTOK.packageName, 18, 14),           // 6 PM, 14 reels
            Triple(TrackedApp.INSTAGRAM_REELS.packageName, 21, 26)   // 9 PM, 26 reels
        )

        for ((pkg, hour, count) in sampleSpecs) {
            val sessionId = UUID.randomUUID().toString()
            val sessionStart = todayStartMillis + (hour * 3_600_000L) + (12 * 60_000L)
            var cursorMillis = sessionStart
            for (i in 0 until count) {
                val dwell = random.nextLong(7_500L, 16_500L)
                cursorMillis += dwell
                events.add(
                    ReelScrollEventEntity(
                        timestampMillis = cursorMillis,
                        dateIso = today.toString(),
                        hourOfDay = hour,
                        packageName = pkg,
                        sessionId = sessionId,
                        dwellTimeMillis = dwell
                    )
                )
            }
            val durationSeconds = ((cursorMillis - sessionStart) / 1000L).coerceAtLeast(count * 8L)
            sessions.add(
                ScrollSessionEntity(
                    sessionId = sessionId,
                    packageName = pkg,
                    dateIso = today.toString(),
                    startTimeMillis = sessionStart,
                    endTimeMillis = cursorMillis,
                    reelCount = count,
                    totalDurationSeconds = durationSeconds
                )
            )
        }

        val todayTotal = events.size
        val todayDur = sessions.sumOf { it.totalDurationSeconds }
        summaries.add(
            DailySummaryEntity(
                dateIso = today.toString(),
                epochDay = today.toEpochDay(),
                totalReels = todayTotal,
                dailyGoal = dailyGoal,
                totalDurationSeconds = todayDur,
                avgSecondsPerReel = if (todayTotal > 0) todayDur.toFloat() / todayTotal else 0f,
                longestSessionSeconds = sessions.maxOfOrNull { it.totalDurationSeconds } ?: 0L,
                peakHour = 21,
                perAppCountsJson = "${TrackedApp.INSTAGRAM_REELS.packageName}:42,${TrackedApp.YOUTUBE_SHORTS.packageName}:22,${TrackedApp.TIKTOK.packageName}:14"
            )
        )

        return Triple(events, sessions, summaries)
    }
}
