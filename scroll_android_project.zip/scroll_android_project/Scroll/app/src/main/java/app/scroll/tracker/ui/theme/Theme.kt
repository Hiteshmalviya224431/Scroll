package app.scroll.tracker.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import app.scroll.tracker.domain.model.ThemePreference

private val AmoledDarkColorScheme = darkColorScheme(
    primary = ElectricViolet,
    onPrimary = Color.White,
    secondary = NeonPink,
    onSecondary = Color.White,
    tertiary = ScrollGreen,
    background = AmoledBlack,
    onBackground = TextPrimaryDark,
    surface = GlassCardSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFF1A1A28),
    onSurfaceVariant = TextSecondaryDark
)

private val CleanLightColorScheme = lightColorScheme(
    primary = Color(0xFF6D28D9),
    onPrimary = Color.White,
    secondary = Color(0xFFDB2777),
    onSecondary = Color.White,
    tertiary = Color(0xFF059669),
    background = LightBackground,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = TextSecondaryLight
)

@Composable
fun ScrollTheme(
    themePreference: ThemePreference = ThemePreference.AMOLED_DARK,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themePreference) {
        ThemePreference.AMOLED_DARK -> true
        ThemePreference.LIGHT -> false
        ThemePreference.SYSTEM -> systemDark
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (useDark) {
                dynamicDarkColorScheme(context).copy(
                    background = if (themePreference == ThemePreference.AMOLED_DARK) AmoledBlack else dynamicDarkColorScheme(context).background
                )
            } else {
                dynamicLightColorScheme(context)
            }
        }
        useDark -> AmoledDarkColorScheme
        else -> CleanLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = ScrollTypography,
        content = content
    )
}
