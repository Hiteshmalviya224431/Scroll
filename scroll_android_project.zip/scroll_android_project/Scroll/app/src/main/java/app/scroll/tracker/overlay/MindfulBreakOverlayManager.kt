package app.scroll.tracker.overlay

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MindfulBreakOverlayManager @Inject constructor() {

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var lifecycleOwner: OverlayLifecycleOwner? = null
    private var lastPromptedReelCount: Int = 0

    fun shouldTriggerPrompt(
        sessionReels: Int,
        sessionDurationSeconds: Long,
        reelsThreshold: Int,
        minutesThreshold: Int
    ): Boolean {
        if (sessionReels <= 0) {
            lastPromptedReelCount = 0
            return false
        }
        val hitReelMultiple = sessionReels >= reelsThreshold &&
            (sessionReels - lastPromptedReelCount) >= reelsThreshold
        val hitTimeThreshold = (sessionDurationSeconds / 60L) >= minutesThreshold &&
            lastPromptedReelCount == 0
        return hitReelMultiple || hitTimeThreshold
    }

    fun showMindfulBreak(
        serviceContext: Context,
        sessionReels: Int,
        sessionMinutes: Int,
        appName: String
    ) {
        if (overlayView != null) return
        lastPromptedReelCount = sessionReels

        val wm = serviceContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val owner = OverlayLifecycleOwner().apply { onCreate() }
        lifecycleOwner = owner

        val view = ComposeView(serviceContext).apply {
            owner.attachToView(this)
            setContent {
                MindfulBreakScreenContent(
                    sessionReels = sessionReels,
                    sessionMinutes = sessionMinutes,
                    appName = appName,
                    onTakeBreak = {
                        dismiss()
                        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_HOME)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        runCatching { serviceContext.startActivity(homeIntent) }
                    },
                    onContinueScrolling = {
                        dismiss()
                    }
                )
            }
        }
        overlayView = view
        runCatching { wm.addView(view, params) }
    }

    fun dismiss() {
        val wm = windowManager
        val view = overlayView
        if (wm != null && view != null) {
            runCatching { wm.removeViewImmediate(view) }
        }
        lifecycleOwner?.onDestroy()
        lifecycleOwner = null
        overlayView = null
    }
}

@Composable
fun MindfulBreakScreenContent(
    sessionReels: Int,
    sessionMinutes: Int,
    appName: String,
    onTakeBreak: () -> Unit,
    onContinueScrolling: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "breathingTransition")
    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathScale"
    )

    val violetPinkGradient = Brush.linearGradient(
        colors = listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF2050508))
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterVertically,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "MINDFUL PAUSE",
                color = Color(0xFFC084FC),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "You've scrolled $sessionReels reels in $appName",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${sessionMinutes.coerceAtLeast(1)} minutes in this session • Take one slow breath before choosing.",
                color = Color(0xFFA1A1AA),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(44.dp))

            // Animated breathing orb
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(180.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(breathScale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0x668B5CF6),
                                    Color(0x22EC4899),
                                    Color.Transparent
                                )
                            )
                        )
                        .border(1.5.dp, Color(0x88C084FC), CircleShape)
                )
                Text(
                    text = if (breathScale < 0.98f) "Breathe In" else "Breathe Out",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(44.dp))

            Button(
                onClick = onTakeBreak,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(violetPinkGradient, RoundedCornerShape(20.dp))
            ) {
                Text(
                    text = "Take a Break (Close App)",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onContinueScrolling,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = "Continue Scrolling",
                    color = Color(0xFFA1A1AA),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
