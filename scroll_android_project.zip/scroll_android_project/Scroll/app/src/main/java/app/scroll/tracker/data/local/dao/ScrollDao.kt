package app.scroll.tracker.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import app.scroll.tracker.data.local.entity.DailySummaryEntity
import app.scroll.tracker.data.local.entity.ReelScrollEventEntity
import app.scroll.tracker.data.local.entity.ScrollSessionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ScrollDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScrollEvent(event: ReelScrollEventEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScrollEvents(events: List<ReelScrollEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSession(session: ScrollSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSessions(sessions: List<ScrollSessionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailySummary(summary: DailySummaryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDailySummaries(summaries: List<DailySummaryEntity>)

    @Query("SELECT * FROM reel_scroll_events WHERE dateIso = :dateIso ORDER BY timestampMillis ASC")
    fun observeEventsForDate(dateIso: String): Flow<List<ReelScrollEventEntity>>

    @Query("SELECT * FROM reel_scroll_events WHERE dateIso = :dateIso ORDER BY timestampMillis ASC")
    suspend fun getEventsForDate(dateIso: String): List<ReelScrollEventEntity>

    @Query("SELECT COUNT(*) FROM reel_scroll_events WHERE dateIso = :dateIso")
    fun observeReelCountForDate(dateIso: String): Flow<Int>

    @Query("SELECT * FROM scroll_sessions WHERE dateIso = :dateIso ORDER BY startTimeMillis DESC")
    fun observeSessionsForDate(dateIso: String): Flow<List<ScrollSessionEntity>>

    @Query("SELECT * FROM scroll_sessions WHERE dateIso = :dateIso ORDER BY startTimeMillis DESC")
    suspend fun getSessionsForDate(dateIso: String): List<ScrollSessionEntity>

    @Query("SELECT * FROM daily_summaries ORDER BY epochDay DESC LIMIT :limit")
    fun observeRecentDailySummaries(limit: Int = 60): Flow<List<DailySummaryEntity>>

    @Query("SELECT * FROM daily_summaries ORDER BY epochDay DESC")
    suspend fun getAllDailySummaries(): List<DailySummaryEntity>

    @Query("SELECT * FROM reel_scroll_events ORDER BY timestampMillis DESC")
    suspend fun getAllEvents(): List<ReelScrollEventEntity>

    @Query("DELETE FROM reel_scroll_events WHERE timestampMillis < :cutoffMillis")
    suspend fun deleteEventsOlderThan(cutoffMillis: Long): Int

    @Query("DELETE FROM scroll_sessions WHERE startTimeMillis < :cutoffMillis")
    suspend fun deleteSessionsOlderThan(cutoffMillis: Long): Int

    @Query("DELETE FROM reel_scroll_events")
    suspend fun clearAllEvents()

    @Query("DELETE FROM scroll_sessions")
    suspend fun clearAllSessions()

    @Query("DELETE FROM daily_summaries")
    suspend fun clearAllSummaries()

    @Transaction
    suspend fun resetAllData() {
        clearAllEvents()
        clearAllSessions()
        clearAllSummaries()
    }
}
