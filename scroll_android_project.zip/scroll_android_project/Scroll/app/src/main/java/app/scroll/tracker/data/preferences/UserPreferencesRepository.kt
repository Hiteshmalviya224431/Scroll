package app.scroll.tracker.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.scroll.tracker.domain.model.NotchPosition
import app.scroll.tracker.domain.model.NotchSize
import app.scroll.tracker.domain.model.ScrollSettings
import app.scroll.tracker.domain.model.ThemePreference
import app.scroll.tracker.domain.model.TrackedApp
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "scroll_settings")

@Singleton
class UserPreferencesRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
        val HAS_ACCEPTED_DISCLOSURE = booleanPreferencesKey("has_accepted_accessibility_disclosure")
        val DAILY_REEL_GOAL = intPreferencesKey("daily_reel_goal")
        val GREEN_THRESHOLD = intPreferencesKey("green_threshold")
        val AMBER_THRESHOLD = intPreferencesKey("amber_threshold")
        val NOTCH_POSITION = stringPreferencesKey("notch_position")
        val NOTCH_SIZE = stringPreferencesKey("notch_size")
        val NOTCH_OPACITY = floatPreferencesKey("notch_opacity")
        val ALWAYS_SHOW_OVERLAY = booleanPreferencesKey("always_show_overlay")
        val HIDE_ON_LOCKSCREEN = booleanPreferencesKey("hide_on_lockscreen")
        val TRACKED_PACKAGES = stringSetPreferencesKey("tracked_packages")
        val NUDGE_80 = booleanPreferencesKey("nudge_80")
        val NUDGE_100 = booleanPreferencesKey("nudge_100")
        val MINDFUL_BREAK_ENABLED = booleanPreferencesKey("mindful_break_enabled")
        val MINDFUL_BREAK_REELS = intPreferencesKey("mindful_break_reels")
        val MINDFUL_BREAK_MINUTES = intPreferencesKey("mindful_break_minutes")
        val QUIET_HOURS_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
        val QUIET_START_HOUR = intPreferencesKey("quiet_start_hour")
        val QUIET_END_HOUR = intPreferencesKey("quiet_end_hour")
        val THEME_PREF = stringPreferencesKey("theme_preference")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color_enabled")
    }

    val settingsFlow: Flow<ScrollSettings> = context.dataStore.data.map { prefs ->
        ScrollSettings(
            hasCompletedOnboarding = prefs[Keys.HAS_COMPLETED_ONBOARDING] ?: false,
            hasAcceptedAccessibilityDisclosure = prefs[Keys.HAS_ACCEPTED_DISCLOSURE] ?: false,
            dailyReelGoal = prefs[Keys.DAILY_REEL_GOAL] ?: 100,
            greenThreshold = prefs[Keys.GREEN_THRESHOLD] ?: 50,
            amberThreshold = prefs[Keys.AMBER_THRESHOLD] ?: 150,
            notchPosition = prefs[Keys.NOTCH_POSITION]?.let {
                runCatching { NotchPosition.valueOf(it) }.getOrNull()
            } ?: NotchPosition.RIGHT,
            notchSize = prefs[Keys.NOTCH_SIZE]?.let {
                runCatching { NotchSize.valueOf(it) }.getOrNull()
            } ?: NotchSize.STANDARD,
            notchOpacity = prefs[Keys.NOTCH_OPACITY] ?: 0.92f,
            alwaysShowOverlay = prefs[Keys.ALWAYS_SHOW_OVERLAY] ?: false,
            hideOverlayOnLockscreen = prefs[Keys.HIDE_ON_LOCKSCREEN] ?: true,
            trackedPackages = prefs[Keys.TRACKED_PACKAGES] ?: TrackedApp.defaultPackages,
            nudgeAt80Percent = prefs[Keys.NUDGE_80] ?: true,
            nudgeAt100Percent = prefs[Keys.NUDGE_100] ?: true,
            mindfulBreakEnabled = prefs[Keys.MINDFUL_BREAK_ENABLED] ?: true,
            mindfulBreakReelsThreshold = prefs[Keys.MINDFUL_BREAK_REELS] ?: 35,
            mindfulBreakMinutesThreshold = prefs[Keys.MINDFUL_BREAK_MINUTES] ?: 15,
            quietHoursEnabled = prefs[Keys.QUIET_HOURS_ENABLED] ?: false,
            quietStartHour = prefs[Keys.QUIET_START_HOUR] ?: 23,
            quietEndHour = prefs[Keys.QUIET_END_HOUR] ?: 7,
            themePreference = prefs[Keys.THEME_PREF]?.let {
                runCatching { ThemePreference.valueOf(it) }.getOrNull()
            } ?: ThemePreference.AMOLED_DARK,
            dynamicColorEnabled = prefs[Keys.DYNAMIC_COLOR] ?: false
        )
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.HAS_COMPLETED_ONBOARDING] = completed }
    }

    suspend fun setAccessibilityDisclosureAccepted(accepted: Boolean) {
        context.dataStore.edit { it[Keys.HAS_ACCEPTED_DISCLOSURE] = accepted }
    }

    suspend fun updateDailyGoal(goal: Int) {
        context.dataStore.edit { it[Keys.DAILY_REEL_GOAL] = goal.coerceIn(10, 1000) }
    }

    suspend fun updateThresholds(greenMax: Int, amberMax: Int) {
        context.dataStore.edit {
            it[Keys.GREEN_THRESHOLD] = greenMax.coerceAtLeast(10)
            it[Keys.AMBER_THRESHOLD] = amberMax.coerceAtLeast(greenMax + 10)
        }
    }

    suspend fun updateNotchPosition(position: NotchPosition) {
        context.dataStore.edit { it[Keys.NOTCH_POSITION] = position.name }
    }

    suspend fun updateNotchSize(size: NotchSize) {
        context.dataStore.edit { it[Keys.NOTCH_SIZE] = size.name }
    }

    suspend fun updateNotchOpacity(opacity: Float) {
        context.dataStore.edit { it[Keys.NOTCH_OPACITY] = opacity.coerceIn(0.3f, 1.0f) }
    }

    suspend fun updateAlwaysShowOverlay(alwaysShow: Boolean) {
        context.dataStore.edit { it[Keys.ALWAYS_SHOW_OVERLAY] = alwaysShow }
    }

    suspend fun updateHideOnLockscreen(hide: Boolean) {
        context.dataStore.edit { it[Keys.HIDE_ON_LOCKSCREEN] = hide }
    }

    suspend fun toggleTrackedPackage(packageName: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.TRACKED_PACKAGES]?.toMutableSet()
                ?: TrackedApp.defaultPackages.toMutableSet()
            if (enabled) current.add(packageName) else current.remove(packageName)
            prefs[Keys.TRACKED_PACKAGES] = current
        }
    }

    suspend fun updateNudgeSettings(nudge80: Boolean, nudge100: Boolean) {
        context.dataStore.edit {
            it[Keys.NUDGE_80] = nudge80
            it[Keys.NUDGE_100] = nudge100
        }
    }

    suspend fun updateMindfulBreakSettings(enabled: Boolean, reelsThreshold: Int, minutesThreshold: Int) {
        context.dataStore.edit {
            it[Keys.MINDFUL_BREAK_ENABLED] = enabled
            it[Keys.MINDFUL_BREAK_REELS] = reelsThreshold.coerceIn(5, 250)
            it[Keys.MINDFUL_BREAK_MINUTES] = minutesThreshold.coerceIn(2, 120)
        }
    }

    suspend fun updateQuietHours(enabled: Boolean, startHour: Int, endHour: Int) {
        context.dataStore.edit {
            it[Keys.QUIET_HOURS_ENABLED] = enabled
            it[Keys.QUIET_START_HOUR] = startHour.coerceIn(0, 23)
            it[Keys.QUIET_END_HOUR] = endHour.coerceIn(0, 23)
        }
    }

    suspend fun updateTheme(themePreference: ThemePreference, dynamicColor: Boolean) {
        context.dataStore.edit {
            it[Keys.THEME_PREF] = themePreference.name
            it[Keys.DYNAMIC_COLOR] = dynamicColor
        }
    }
}
