package app.scroll.tracker.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "reel_scroll_events",
    indices = [
        Index(value = ["timestampMillis"]),
        Index(value = ["dateIso"]),
        Index(value = ["sessionId"])
    ]
)
data class ReelScrollEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestampMillis: Long,
    val dateIso: String, // YYYY-MM-DD in local time
    val hourOfDay: Int,  // 0..23
    val packageName: String,
    val sessionId: String,
    val dwellTimeMillis: Long // milliseconds spent on previous reel before swiping
)

@Entity(
    tableName = "scroll_sessions",
    indices = [Index(value = ["dateIso"]), Index(value = ["startTimeMillis"])]
)
data class ScrollSessionEntity(
    @PrimaryKey
    val sessionId: String,
    val packageName: String,
    val dateIso: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val reelCount: Int,
    val totalDurationSeconds: Long
)

@Entity(tableName = "daily_summaries")
data class DailySummaryEntity(
    @PrimaryKey
    val dateIso: String, // YYYY-MM-DD
    val epochDay: Long,
    val totalReels: Int,
    val dailyGoal: Int,
    val totalDurationSeconds: Long,
    val avgSecondsPerReel: Float,
    val longestSessionSeconds: Long,
    val peakHour: Int,
    val perAppCountsJson: String // simple serialized key=value pairs e.g. "com.instagram.android:48,com.google.android.youtube:32"
)
