package app.scroll.tracker.domain.tracker

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class SessionTrackerTest {

    private var counter = 0
    private lateinit var sessionTracker: SessionTracker

    @Before
    fun setUp() {
        counter = 0
        sessionTracker = SessionTracker(
            sessionTimeoutMillis = 60_000L,
            idGenerator = { "session_${++counter}" }
        )
    }

    @Test
    fun `groups consecutive scrolls within 60 seconds into same session`() {
        val first = sessionTracker.recordScroll("com.instagram.android", 10_000L)
        val second = sessionTracker.recordScroll("com.instagram.android", 22_000L) // +12s
        val third = sessionTracker.recordScroll("com.instagram.android", 69_000L)  // +47s

        assertTrue(first.isNewSession)
        assertFalse(second.isNewSession)
        assertFalse(third.isNewSession)
        assertEquals("session_1", third.sessionId)
        assertEquals(3, third.updatedSession.reelCount)
    }

    @Test
    fun `starts new session after 60 seconds of inactivity`() {
        val first = sessionTracker.recordScroll("com.instagram.android", 10_000L)
        val afterTimeout = sessionTracker.recordScroll("com.instagram.android", 75_000L) // +65s (> 60s)

        assertTrue(first.isNewSession)
        assertTrue(afterTimeout.isNewSession)
        assertNotEquals(first.sessionId, afterTimeout.sessionId)
        assertEquals("session_2", afterTimeout.sessionId)
        assertEquals(1, afterTimeout.updatedSession.reelCount)
        assertNull(sessionTracker.getActiveSession(140_000L))
    }

    @Test
    fun `starts new session immediately when switching tracked apps`() {
        val igScroll = sessionTracker.recordScroll("com.instagram.android", 10_000L)
        val ytScroll = sessionTracker.recordScroll("com.google.android.youtube", 15_000L)

        assertTrue(igScroll.isNewSession)
        assertTrue(ytScroll.isNewSession)
        assertEquals("session_1", igScroll.sessionId)
        assertEquals("session_2", ytScroll.sessionId)
    }
}
