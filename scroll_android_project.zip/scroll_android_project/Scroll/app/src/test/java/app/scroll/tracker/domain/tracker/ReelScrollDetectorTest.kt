package app.scroll.tracker.domain.tracker

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ReelScrollDetectorTest {

    private lateinit var detector: ReelScrollDetector

    @Before
    fun setUp() {
        detector = ReelScrollDetector(debounceMillis = 400L)
    }

    @Test
    fun `counts first valid vertical pager scroll in foreground reels screen`() {
        val candidate = ReelScrollDetector.ScrollCandidate(
            packageName = "com.instagram.android",
            timestampMillis = 1_000L,
            isForeground = true,
            isInReelsScreen = true,
            className = "androidx.viewpager2.widget.ViewPager2",
            fromIndex = 0,
            toIndex = 1,
            itemCount = 50,
            scrollDeltaY = 800
        )

        assertTrue(detector.onScrollCandidate(candidate))
    }

    @Test
    fun `debounces duplicate scroll events within 400ms window`() {
        val first = ReelScrollDetector.ScrollCandidate(
            packageName = "com.instagram.android",
            timestampMillis = 1_000L,
            isForeground = true,
            isInReelsScreen = true,
            className = "androidx.recyclerview.widget.RecyclerView",
            fromIndex = 1,
            toIndex = 2,
            itemCount = 50,
            scrollDeltaY = 900
        )
        val duplicateWithinDebounce = first.copy(
            timestampMillis = 1_250L, // +250ms (< 400ms)
            fromIndex = 2,
            toIndex = 3
        )
        val nextValidAfterDebounce = first.copy(
            timestampMillis = 1_450L, // +450ms (>= 400ms)
            fromIndex = 2,
            toIndex = 3
        )

        assertTrue(detector.onScrollCandidate(first))
        assertFalse("Should ignore scroll within 400ms debounce window", detector.onScrollCandidate(duplicateWithinDebounce))
        assertTrue("Should count scroll after 400ms debounce window", detector.onScrollCandidate(nextValidAfterDebounce))
    }

    @Test
    fun `ignores scroll when not in reels screen or same page index`() {
        val first = ReelScrollDetector.ScrollCandidate(
            packageName = "com.google.android.youtube",
            timestampMillis = 2_000L,
            isForeground = true,
            isInReelsScreen = true,
            className = "androidx.recyclerview.widget.RecyclerView",
            fromIndex = 5,
            toIndex = 5,
            itemCount = 100,
            scrollDeltaY = 0
        )
        val samePageLater = first.copy(timestampMillis = 3_000L)
        val nonReelsScreen = first.copy(
            timestampMillis = 4_000L,
            isInReelsScreen = false,
            fromIndex = 6,
            toIndex = 7
        )

        assertTrue(detector.onScrollCandidate(first))
        assertFalse("Should not count when adapter index has not changed", detector.onScrollCandidate(samePageLater))
        assertFalse("Should not count when user is not in Reels/Shorts screen", detector.onScrollCandidate(nonReelsScreen))
    }
}
