# Scroll — Native Android Short-Video Reel Counter & Notch Live Pill

**Scroll** is a privacy-first, 100% offline Android app built with **Kotlin, Jetpack Compose, Material 3 (AMOLED Dark + Electric Violet-to-Pink gradient), Hilt, Room, DataStore, WorkManager, Vico, and Glance**. It tracks how many short-video reels you swipe through each day, renders a tiny non-touchable live counter pill (`▶ 128`) right beside your camera cutout, and visualizes your scrolling habits.

## Architecture & Highlights

- **Pure Event-Driven Tracking (`ScrollAccessibilityService`)**: Listens to `TYPE_VIEW_SCROLLED` and `TYPE_WINDOW_CONTENT_CHANGED` for Instagram Reels, YouTube Shorts, Facebook Reels, TikTok, Snapchat Spotlight, Moj, and Josh.
- **400ms Debounce & Vertical Pager Detection (`ReelScrollDetector`)**: Counts only genuine `ViewPager2` / `RecyclerView` vertical page changes while the app is in the foreground and on its Reels/Shorts feed.
- **60-Second Session Engine (`SessionTracker`)**: Automatically groups consecutive swipes into sessions and closes a session after 60 seconds of inactivity.
- **Cutout-Aware Live Counter Pill (`NotchOverlayManager`)**: Uses `TYPE_ACCESSIBILITY_OVERLAY` (no separate overlay permission required) + `FLAG_NOT_TOUCHABLE` and `WindowInsets.displayCutout` (`boundingRects`) to hug the left or right edge of the camera cutout (with top-center fallback), complete with rolling number animations, scale pulses, and threshold color shifts (`Green <50`, `Amber 50–150`, `Red 150+`).
- **Mindful Break Breathing Overlay (`MindfulBreakOverlayManager`)**: Displays a 4-second inhale/exhale breathing animation after *N* consecutive reels or *M* minutes with *Take a Break* vs. *Continue* choices.
- **Midnight Rollup (`DailyRollupWorker`)**: Uses WorkManager to aggregate daily summaries at midnight and prune raw event timestamps older than 90 days while retaining `DailySummaryEntity` history forever.
- **Zero Network Access**: `AndroidManifest.xml` does **not** request `android.permission.INTERNET`.

## Setup Steps

1. **Open in Android Studio**: Open the `Scroll` project folder in **Android Studio Ladybug (2024.2.1+)** with **JDK 17** and **Android SDK 35**.
2. **Run on Device or Emulator (Min SDK 26 / Target SDK 35)**:
   ```bash
   ./gradlew assembleDebug
   ./gradlew testDebugUnitTest
   ```
3. **Enable Accessibility Service**:
   - Complete the 3-screen onboarding inside the app.
   - Accept the Play Store-compliant **Accessibility Service Disclosure** dialog, which opens **Settings → Accessibility → Installed apps → Scroll Reel Counter & Notch Pill**, and toggle it **On**.
4. **Test Immediately**:
   - Open Instagram Reels, YouTube Shorts, or TikTok and swipe vertically — watch the live counter pill beside your camera cutout tick up and pulse!
   - Or open **Settings → Debug Console • Simulate Reel Scrolls** (or tap `+1 Demo Swipe` on the Today screen) to test the rolling animations, session timeline, and charts immediately.
